using Microsoft.VisualStudio.TestPlatform.TestHost;
using System;
using sea

namespace sea_battle_test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestInitialize()
        {
            Program.InitializeBoard();
            Program.shipsPlaced = 0;
        }

        [TestMethod]
        public void ParseCoordinates_ValidInput_ReturnsTrue()
        {
            string input = "2 5 3 3";

            bool result = Program.ParseCoordinates(input, out int x1, out int x2, out int y1, out int y2);

            Assert.IsTrue(result);
            Assert.AreEqual(2, x1);
            Assert.AreEqual(5, x2);
            Assert.AreEqual(3, y1);
            Assert.AreEqual(3, y2);
        }

        [TestMethod]
        public void ParseCoordinates_InvalidInput_ReturnsFalse()
        {
            // Arrange
            string input = "2 abc 3 3";

            // Act
            bool result = Program.ParseCoordinates(input, out _, out _, out _, out _);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryPlaceShip_HorizontalValidPlacement_ReturnsTrue()
        {
            // Act
            bool result = Program.TryPlaceShip(0, 3, 5, 5, 4);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TryPlaceShip_VerticalValidPlacement_ReturnsTrue()
        {
            // Act
            bool result = Program.TryPlaceShip(5, 5, 0, 3, 4);

            // Assert
            Assert.IsTrue(result);
        }

        [TestMethod]
        public void TryPlaceShip_OutOfBounds_ReturnsFalse()
        {
            // Act
            bool result = Program.TryPlaceShip(7, 10, 5, 5, 4);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryPlaceShip_Diagonal_ReturnsFalse()
        {
            // Act
            bool result = Program.TryPlaceShip(0, 3, 0, 3, 4);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryPlaceShip_WrongSize_ReturnsFalse()
        {
            // Act
            bool result = Program.TryPlaceShip(0, 2, 5, 5, 4);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryPlaceShip_Overlap_ReturnsFalse()
        {
            // Arrange
            Program.TryPlaceShip(2, 5, 3, 3, 4);

            // Act
            bool result = Program.TryPlaceShip(3, 3, 2, 5, 4);

            // Assert
            Assert.IsFalse(result);
        }

        [TestMethod]
        public void TryPlaceShip_Adjacent_ReturnsFalse()
        {
            // Arrange
            Program.TryPlaceShip(2, 5, 3, 3, 4);

            // Act
            bool result = Program.TryPlaceShip(1, 6, 4, 4, 4);

            // Assert
            Assert.IsFalse(result);
        }
    }
}