﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract8_shengals_Roman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            comboBox1.Items.AddRange(new object[] {1, 2, 3, 4, 5});
            comboBox1.SelectedIndexChanged += ComboBox1_SelectedIndexChanged;
            this.Load += Form1_Load;
            button1.Click += ButtonCalculate_Click;
        }

        private void ButtonCalculate_Click(object sender, EventArgs e)
        {
            int count = listBox1.Items.Count;
            int sum = 0;
            int oddCount = 0;
            int evenCount = 0;

            foreach (var item in listBox1.Items)
            {
                int number = (int)item;
                sum += number;

                if (number % 2 == 0)
                    evenCount++;
                else
                    oddCount++;
            }

            MessageBox.Show(
                $"Количество чисел: {count}\n" +
                $"Сумма чисел: {sum}\n" +
                $"Количество нечетных чисел: {oddCount}\n" +
                $"Количество четных чисел: {evenCount}",
                "Результаты",
                MessageBoxButtons.OK,
                MessageBoxIcon.Information
            );
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            FillBox();
        }
        private void FillBox()
        {
            listBox1.Items.Clear();
            for (int i = 0; i <= 100; i++)
            {
                if (IsPrime(i))
                {
                    listBox1.Items.Add(i);
                }
            }
        }
        private bool IsPrime(int number)
        {
            if (number <= 1)
            {
                return false;
            }
            for (int i = 2; i * i <= number; i++)
            {
                if (number % i == 0)
                {
                    return false;
                }
            }
            return true;
        }
        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            int selectedNumber = (int)comboBox1.SelectedItem;
            string descript = GetDescript(selectedNumber);
            label1.Text = descript;
        }
        private string GetDescript(int grade)
        {
            switch (grade)
            {
                case 1:
                    return "Плохо";
                case 2:
                    return "Неудовлетворительно";
                case 3:
                    return "Удовлетворительно";
                case 4:
                    return "Хорошо";
                case 5:
                    return "Отлично";
                default:
                    return "Неизвестная оценка";
            }
        }
        public enum Светофор { Красный, Жёлтый, Зеленый}
        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            Светофор signal = (Светофор)comboBox2.SelectedIndex;
            switch (signal)
            {
                case Светофор.Красный:
                    label6.Text = "Стойте!";
                    label6.BackColor = Color.Red;
                    break;
                case Светофор.Жёлтый:
                    label6.Text = "Ждите";
                    label6.BackColor = Color.Yellow;
                    break;
                case Светофор.Зеленый:
                    label6.Text = "Идите";
                    label6.BackColor = Color.Green;
                    break;
                default:
                    MessageBox.Show("Светофор сломан");
                    break;
            }
        }
        public enum Радуга {Красный, Оранжевый, Желтый, Зеленый, Голубой, Синий, Фиолетовый}

        private void comboBox3_SelectedIndexChanged(object sender, EventArgs e)
        {
            Радуга signal = (Радуга)comboBox3.SelectedIndex;
            switch (signal)
            {
                case Радуга.Красный:
                    label9.Text = "Каждый";
                    label9.BackColor = Color.Red;
                    break;
                case Радуга.Оранжевый:
                    label9.Text = "Охотник";
                    label9.BackColor = Color.Orange;
                    break;
                case Радуга.Желтый:
                    label9.Text = "Желает";
                    label9.BackColor = Color.Yellow;
                    break;
                case Радуга.Зеленый:
                    label9.Text = "Знать";
                    label9.BackColor = Color.Green;
                    break;
                case Радуга.Голубой:
                    label9.Text = "Где";
                    label9.ForeColor = Color.White;
                    label9.BackColor = Color.Blue;
                    break;
                case Радуга.Синий:
                    label9.Text = "Сидит";
                    label9.ForeColor = Color.White;
                    label9.BackColor = Color.DarkBlue;
                    break;
                case Радуга.Фиолетовый:
                    label9.Text = "Фазан";
                    label9.BackColor = Color.Purple;
                    break;
                default:
                    MessageBox.Show("Такого цвета нету");
                    break;
            }
        }
        public enum Месяц {Январь, Февраль, Март, Апрель, Май, Июнь, Июль, Август, Сентябрь, Октябрь, Ноябрь, Декабрь}

        private void comboBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            Месяц month = (Месяц)comboBox4.SelectedIndex;
            switch (month)
            {
                case Месяц.Январь:
                    label11.Text = "Предыдущий месяц:\nДекабрь: 31";
                    break;
                case Месяц.Февраль:
                    label11.Text = "Предыдущий месяц:\nЯнварь: 31";
                    break;
                case Месяц.Март:
                    label11.Text = "Предыдущий месяц:\nФевраль: 28";
                    break;
                case Месяц.Апрель:
                    label11.Text = "Предыдущий месяц:\nМарт: 31";
                    break;
                case Месяц.Май:
                    label11.Text = "Предыдущий месяц:\nАпрель: 30";
                    break;
                case Месяц.Июнь:
                    label11.Text = "Предыдущий месяц:\nМай: 31";
                    break;
                case Месяц.Июль:
                    label11.Text = "Предыдущий месяц:\nИюнь: 30";
                    break;
                case Месяц.Август:
                    label11.Text = "Предыдущий месяц:\nИюль: 31";
                    break;
                case Месяц.Сентябрь:
                    label11.Text = "Предыдущий месяц:\nАвгуст: 31";
                    break;
                case Месяц.Октябрь:
                    label11.Text = "Предыдущий месяц:\nСентябрь: 30";
                    break;
                case Месяц.Ноябрь:
                    label11.Text = "Предыдущий месяц:\nОктябрь: 31";
                    break;
                case Месяц.Декабрь:
                    label11.Text = "Предыдущий месяц:\nstНоябрь: 31";
                    break;
                default:
                    MessageBox.Show("Такой даты не существует.");
                    break;

            }
        }
    }
}
