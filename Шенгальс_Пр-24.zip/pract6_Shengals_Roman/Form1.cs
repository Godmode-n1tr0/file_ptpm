﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract8_Shengals_Roman
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string meeLogin = checkLogin(Login.Text);
            string meeNumber = checknumber(number.Text);
            string meeEmail = checkemail(email.Text);
            if (meeLogin + meeNumber + meeEmail == "" && password.Text != "")
            {
                MessageBox.Show("Сохранено успешно", "Сохранение");
            }
            else
            {
                MessageBox.Show($"{meeLogin}\n{meeNumber}\n{meeEmail}", "Ошибка");
            }
        }
        string checknumber(string textnumber)
        {
            string a = "";
            string b = "";
            
            if (textnumber == string.Empty)
            {
                a = "Номер не может быть пустым.";
            }
            for (int i = 1; i < textnumber.Length; i++)
            {

                if (!char.IsNumber(textnumber[i]))
                {
                    a = "В телефоне могут быть только цифры.";
                    break;
                }
            }
            if (textnumber.Contains("+7"))
            {
                if (textnumber.Length == 12)
                {
                    return a;
                }
                else
                {
                    a = "Вы ввели не полный номер.";
                }
            }
            if (textnumber.Contains("8"))
            {
                if (textnumber.Length == 11)
                {
                    return a;
                }
                else
                {
                    a = "Вы ввели не полный номер.";
                }
            }
            return a;

        }
        static bool IsValidEmail(string email)
        {
            int atIndex = email.IndexOf('@');
            int dotIndex = email.IndexOf('.', atIndex);

            if (atIndex <= 0 || dotIndex <= atIndex + 1 || dotIndex >= email.Length - 1)
            {
                return false;
            }
            string localPart = email.Substring(0, atIndex);
            string domainPart = email.Substring(atIndex + 1, dotIndex - atIndex - 1);
            string topLevelDomain = email.Substring(dotIndex + 1);

            return IsValidPart(localPart) && IsValidPart(domainPart) && IsValidPart(topLevelDomain);
        }

        static bool IsValidPart(string part)
        {
            return part.All(c => char.IsLetter(c) || char.IsDigit(c));
        }
        string checkemail(string textemail)
        {
            string a = "";
            int count = 0;
            int count2 = 0;
            if (textemail == string.Empty)
            {
                a = "Вы не можете оставить поле почты пустым.";
            }
            if (IsValidEmail(textemail))
            {
                return a;
            }
            else
            {
                a = "Email некорректен.";
            }
            return a;
        }
        string checkLogin(string textlogin)
        {
            string a = "";
            if (textlogin != string.Empty)
            {
                if (textlogin.Length >= 5 && textlogin.Length <= 12)
                {
                    for (int i = 0; i < textlogin.Length; i++)
                    {
                        if (!char.IsLetter(textlogin[i]))
                        {
                            a = "В логине могут быть только буквы.";
                            break;
                        }
                    }
                }
                else
                {
                    a = "Введите логин длиной от 5 до 12 символов.";
                }
            }
            else
            {
                a = "Ошибка. Вы оставили поле Логин пустым.";
            }
            return a;
        }
    }
}
