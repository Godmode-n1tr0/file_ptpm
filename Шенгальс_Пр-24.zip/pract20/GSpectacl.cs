﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract20
{
    public class GSpectacl : Spectacl
    {
        private DateTime _tourStart;
        private DateTime _tourEnd;
        private string _venue;

        public GSpectacl(string title, string genre, string author, string director, DateTime tourStart, DateTime tourEnd, string venue, bool checkDatesNotPast = false): base(title, genre, author, director)
        {
            string errors = string.Empty;
            errors += Validation.ValidateDates(tourStart, tourEnd, "Дата начала", "Дата окончания", checkDatesNotPast);
            errors += Validation.ValidateString(venue, "Площадка");

            if (!string.IsNullOrEmpty(errors))
            {
                AllSpectacles.RemoveAt(0);
                throw new ArgumentException(errors);
            }
            _tourStart = tourStart;
            _tourEnd = tourEnd;
            _venue = venue;
        }

        public DateTime TourStart => _tourStart;
        public DateTime TourEnd => _tourEnd;
        public string Venue => _venue;

        public override string Info()
        {
            return $"\nГАСТРОЛЬНЫЙ СПЕКТАКЛЬ: {Title}\n" +
                   $"Жанр: {Genre}\n" +
                   $"Автор: {Author}\n" +
                   $"Режиссер: {Director}\n" +
                   $"Гастроли с: {TourStart:dd.MM.yyyy} по {TourEnd:dd.MM.yyyy}\n" +
                   $"Площадка: {Venue}\n";
        }
    }
}
