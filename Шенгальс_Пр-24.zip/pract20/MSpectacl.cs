﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract20
{
    public class MSpectacl : Spectacl
    {
        private string _theaterName;
        private int _performancesPerSeason;

        public MSpectacl(string title, string genre, string author, string director,string theaterName, int performancesPerSeason): base(title, genre, author, director)
        {
            string errors = string.Empty;
            errors += Validation.ValidateString(theaterName, "Название театра");
            errors += Validation.ValidatePositiveNumber(performancesPerSeason, "Количество показов");

            if (!string.IsNullOrEmpty(errors))
            {
                AllSpectacles.RemoveAt(0);
                throw new ArgumentException(errors);
            }

            _theaterName = theaterName;
            _performancesPerSeason = performancesPerSeason;
        }

        public string TheaterName => _theaterName;
        public int PerformancesPerSeason => _performancesPerSeason;

        public override string Info()
        {
            return $"МЕСТНЫЙ СПЕКТАКЛЬ: {Title}\n" +
                   $"Жанр: {Genre}\n" +
                   $"Автор: {Author}\n" +
                   $"Режиссер: {Director}\n" +
                   $"Театр: {TheaterName}\n" +
                   $"Показов в сезоне: {PerformancesPerSeason}\n";
        }
    }
}
