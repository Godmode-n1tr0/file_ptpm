﻿namespace WorkDB_Shengals
{
    partial class Authorization_frm
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.Log_Txt = new System.Windows.Forms.TextBox();
            this.Pass_Txt = new System.Windows.Forms.TextBox();
            this.Input_btn = new System.Windows.Forms.Button();
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.Вход = new System.Windows.Forms.TabPage();
            this.Регистрация = new System.Windows.Forms.TabPage();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.Valpassword_Txt = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Valinput_btn = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.Valpass_Txt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.Vallog_Txt = new System.Windows.Forms.TextBox();
            this.tabControl1.SuspendLayout();
            this.Вход.SuspendLayout();
            this.Регистрация.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label1.Location = new System.Drawing.Point(265, 85);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(64, 24);
            this.label1.TabIndex = 0;
            this.label1.Text = "Логин";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label2.Location = new System.Drawing.Point(265, 130);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(76, 24);
            this.label2.TabIndex = 1;
            this.label2.Text = "Пароль";
            // 
            // Log_Txt
            // 
            this.Log_Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Log_Txt.Location = new System.Drawing.Point(344, 85);
            this.Log_Txt.Margin = new System.Windows.Forms.Padding(2);
            this.Log_Txt.Name = "Log_Txt";
            this.Log_Txt.Size = new System.Drawing.Size(130, 29);
            this.Log_Txt.TabIndex = 2;
            // 
            // Pass_Txt
            // 
            this.Pass_Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Pass_Txt.Location = new System.Drawing.Point(344, 126);
            this.Pass_Txt.Margin = new System.Windows.Forms.Padding(2);
            this.Pass_Txt.Name = "Pass_Txt";
            this.Pass_Txt.PasswordChar = '*';
            this.Pass_Txt.Size = new System.Drawing.Size(130, 29);
            this.Pass_Txt.TabIndex = 3;
            // 
            // Input_btn
            // 
            this.Input_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Input_btn.Location = new System.Drawing.Point(222, 271);
            this.Input_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Input_btn.Name = "Input_btn";
            this.Input_btn.Size = new System.Drawing.Size(354, 40);
            this.Input_btn.TabIndex = 4;
            this.Input_btn.Text = "Войти в приложение";
            this.Input_btn.UseVisualStyleBackColor = true;
            this.Input_btn.Click += new System.EventHandler(this.Input_btn_Click);
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.Вход);
            this.tabControl1.Controls.Add(this.Регистрация);
            this.tabControl1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Margin = new System.Windows.Forms.Padding(2);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(790, 521);
            this.tabControl1.TabIndex = 6;
            // 
            // Вход
            // 
            this.Вход.Controls.Add(this.Input_btn);
            this.Вход.Controls.Add(this.label1);
            this.Вход.Controls.Add(this.Pass_Txt);
            this.Вход.Controls.Add(this.label2);
            this.Вход.Controls.Add(this.Log_Txt);
            this.Вход.Location = new System.Drawing.Point(4, 22);
            this.Вход.Margin = new System.Windows.Forms.Padding(2);
            this.Вход.Name = "Вход";
            this.Вход.Padding = new System.Windows.Forms.Padding(2);
            this.Вход.Size = new System.Drawing.Size(782, 495);
            this.Вход.TabIndex = 0;
            this.Вход.Text = "Вход";
            this.Вход.UseVisualStyleBackColor = true;
            // 
            // Регистрация
            // 
            this.Регистрация.Controls.Add(this.dataGridView2);
            this.Регистрация.Controls.Add(this.Valpassword_Txt);
            this.Регистрация.Controls.Add(this.label5);
            this.Регистрация.Controls.Add(this.Valinput_btn);
            this.Регистрация.Controls.Add(this.label3);
            this.Регистрация.Controls.Add(this.Valpass_Txt);
            this.Регистрация.Controls.Add(this.label4);
            this.Регистрация.Controls.Add(this.Vallog_Txt);
            this.Регистрация.Location = new System.Drawing.Point(4, 22);
            this.Регистрация.Margin = new System.Windows.Forms.Padding(2);
            this.Регистрация.Name = "Регистрация";
            this.Регистрация.Padding = new System.Windows.Forms.Padding(2);
            this.Регистрация.Size = new System.Drawing.Size(782, 495);
            this.Регистрация.TabIndex = 1;
            this.Регистрация.Text = "Регистрация";
            this.Регистрация.UseVisualStyleBackColor = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Location = new System.Drawing.Point(151, 297);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.RowHeadersWidth = 51;
            this.dataGridView2.Size = new System.Drawing.Size(492, 171);
            this.dataGridView2.TabIndex = 11;
            // 
            // Valpassword_Txt
            // 
            this.Valpassword_Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Valpassword_Txt.Location = new System.Drawing.Point(365, 103);
            this.Valpassword_Txt.Margin = new System.Windows.Forms.Padding(2);
            this.Valpassword_Txt.Name = "Valpassword_Txt";
            this.Valpassword_Txt.PasswordChar = '*';
            this.Valpassword_Txt.Size = new System.Drawing.Size(130, 29);
            this.Valpassword_Txt.TabIndex = 10;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label5.Location = new System.Drawing.Point(136, 103);
            this.label5.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(227, 24);
            this.label5.TabIndex = 9;
            this.label5.Text = "Подтверждение пароля";
            // 
            // Valinput_btn
            // 
            this.Valinput_btn.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Valinput_btn.Location = new System.Drawing.Point(210, 218);
            this.Valinput_btn.Margin = new System.Windows.Forms.Padding(2);
            this.Valinput_btn.Name = "Valinput_btn";
            this.Valinput_btn.Size = new System.Drawing.Size(344, 40);
            this.Valinput_btn.TabIndex = 8;
            this.Valinput_btn.Text = "Войти в приложение";
            this.Valinput_btn.UseVisualStyleBackColor = true;
            this.Valinput_btn.Click += new System.EventHandler(this.Valinput_btn_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label3.Location = new System.Drawing.Point(287, 34);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 24);
            this.label3.TabIndex = 4;
            this.label3.Text = "Логин";
            // 
            // Valpass_Txt
            // 
            this.Valpass_Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Valpass_Txt.Location = new System.Drawing.Point(366, 67);
            this.Valpass_Txt.Margin = new System.Windows.Forms.Padding(2);
            this.Valpass_Txt.Name = "Valpass_Txt";
            this.Valpass_Txt.PasswordChar = '*';
            this.Valpass_Txt.Size = new System.Drawing.Size(130, 29);
            this.Valpass_Txt.TabIndex = 7;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.label4.Location = new System.Drawing.Point(287, 70);
            this.label4.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(76, 24);
            this.label4.TabIndex = 5;
            this.label4.Text = "Пароль";
            // 
            // Vallog_Txt
            // 
            this.Vallog_Txt.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.Vallog_Txt.Location = new System.Drawing.Point(366, 34);
            this.Vallog_Txt.Margin = new System.Windows.Forms.Padding(2);
            this.Vallog_Txt.Name = "Vallog_Txt";
            this.Vallog_Txt.Size = new System.Drawing.Size(130, 29);
            this.Vallog_Txt.TabIndex = 6;
            // 
            // Authorization_frm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoSize = true;
            this.ClientSize = new System.Drawing.Size(790, 521);
            this.Controls.Add(this.tabControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "Authorization_frm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Для входа введите логин и пароль";
            this.tabControl1.ResumeLayout(false);
            this.Вход.ResumeLayout(false);
            this.Вход.PerformLayout();
            this.Регистрация.ResumeLayout(false);
            this.Регистрация.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox Log_Txt;
        private System.Windows.Forms.TextBox Pass_Txt;
        private System.Windows.Forms.Button Input_btn;
        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage Вход;
        private System.Windows.Forms.TabPage Регистрация;
        private System.Windows.Forms.TextBox Valpassword_Txt;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Valinput_btn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox Valpass_Txt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox Vallog_Txt;
        private System.Windows.Forms.DataGridView dataGridView2;
    }
}

