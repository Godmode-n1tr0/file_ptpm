﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract9_Shengals_Roman
{
    internal struct Human
    {
        public string Name { get; set; }
        public string Surname { get; set; }

        public static List<Human> human = new List<Human>();
        public static void LoadFromFile(string fileName)
        {
            human.Clear();
            string[] lines = File.ReadAllLines(fileName);
            foreach (var line in lines)
            {
                string[] parts = line.Trim().Split(' ');
                if (parts.Length >= 2)
                {
                    human.Add(new Human { Surname = parts[0], Name = parts[1] });
                }
            }
        }
        public static void SaveToFile(string fileName)
        {
            List<string> lines = new List<string>();
            foreach (var person in human)
            {
                lines.Add($"{person.Surname} {person.Name}");
            }
            File.WriteAllLines(fileName, lines);
        }
        public override string ToString() => $"{Surname} {Name}";
    }
}
