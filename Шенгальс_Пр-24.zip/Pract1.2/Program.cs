﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract1._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите номер задания: ");
            int a1 = Convert.ToInt32(Console.ReadLine());
            if (a1 == 1)
            {
                Console.Clear();
                Console.WriteLine("Введите путь к файлу для чтения:");
                string filePath = Console.ReadLine();

                try
                {
                    if (File.Exists(filePath))
                    {
                        string content = File.ReadAllText(filePath);
                        Console.WriteLine("Содержимое файла:");
                        Console.WriteLine(content);
                    }
                    else
                    {
                        Console.WriteLine("Файл не найден.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Произошла ошибка: {ex.Message}");
                }
            }
            else if (a1 == 2)
            {
                Console.Clear();
                using (StreamWriter writer = new StreamWriter("file2.txt"))
                {
                    writer.WriteLine("Шенгальс Роман");
                }

                using (StreamReader reader = new StreamReader("file2.txt"))
                {
                    string line = reader.ReadLine();
                    Console.WriteLine("Считанная строка: " + line);
                }
            }
            else if (a1 == 3)
            {
                Console.Clear();
                using (StreamWriter writer = new StreamWriter("file2a.txt"))
                {
                    writer.WriteLine("Иван Иванов");
                    writer.WriteLine("Петр Петров");
                    writer.WriteLine("Сергей Сергеев");
                    writer.WriteLine("Анна Анна");
                    writer.WriteLine("Елена Еленова");
                }

                string[] names = new string[5];
                using (StreamReader reader = new StreamReader("file2a.txt"))
                {
                    for (int i = 0; i < 5; i++)
                    {
                        names[i] = reader.ReadLine();
                    }
                }

                Console.WriteLine("Считанные имена и фамилии:");
                foreach (var name in names)
                {
                    Console.WriteLine(name);
                }
            }
            else if (a1 == 4)
            {
                Console.Clear();
                int lineCount = 0;

                using (StreamReader reader = new StreamReader("file2a.txt"))
                {
                    while (reader.ReadLine() != null)
                    {
                        lineCount++;
                    }
                }

                Console.WriteLine($"Количество строк в файле: {lineCount}");

                Console.WriteLine("Сколько строк вы хотите прочитать?");
                if (int.TryParse(Console.ReadLine(), out int linesToRead) && linesToRead <= lineCount && linesToRead > 0)
                {
                    string[] names = new string[linesToRead];

                    using (StreamReader reader = new StreamReader("file2a.txt"))
                    {
                        for (int i = 0; i < linesToRead; i++)
                        {
                            names[i] = reader.ReadLine();
                        }
                    }

                    Console.WriteLine("Считанные имена и фамилии:");
                    foreach (var name in names)
                    {
                        Console.WriteLine(name);
                    }
                }
                else
                {
                    Console.WriteLine("Некорректный ввод.");
                }
            }
            else if (a1 == 5)
            {
                Console.Clear();
                string characterName = "Герой";
                int health = 100;
                int level = 5;

                string filePath = "f3.txt";

                try
                {
                    using (StreamWriter writer = new StreamWriter(filePath))
                    {
                        writer.WriteLine($"Имя: {characterName}");
                        writer.WriteLine($"Здоровье: {health}");
                        writer.WriteLine($"Уровень: {level}");
                    }
                    Console.WriteLine($"Данные о персонаже успешно записаны в файл {filePath}.");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Произошла ошибка при записи в файл: {ex.Message}");
                }
            }
            else if (a1 == 6)
            {
                Console.Clear();
                string filePath = "file9.txt";

                string content = File.ReadAllText(filePath).Trim();

                switch (content)
                {
                    case "1":
                        Console.WriteLine("Выполняю код под номером один");
                        break;
                    case "2":
                        Console.WriteLine("Выполняю код под номером два");
                        break;
                    case "3":
                        Console.WriteLine("Выполняю код под номером три");
                        break;
                    default:
                        Console.WriteLine("Некорректные значения в стартовом файле");
                        break;
                }
            }
            else if (a1 == 7)
            {
                Console.Clear();
                string filePath = "f1.txt";
                int sum = 0;

                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    if (int.TryParse(line, out int number) && number % 2 == 0)
                    {
                        sum += number;
                    }
                }

                Console.WriteLine($"Сумма четных чисел: {sum}");
            }
            else if (a1 == 8)
            {
                Console.Clear();
                string filePath = "pass.txt";

                Console.Write("Введите логин: ");
                string loginInput = Console.ReadLine();
                Console.Write("Введите пароль: ");
                string passwordInput = Console.ReadLine();

                string[] credentials = File.ReadAllLines(filePath);
                if (credentials.Length >= 2)
                {
                    string login = credentials[0];
                    string password = credentials[1];

                    if (loginInput == login && passwordInput == password)
                    {
                        Console.WriteLine("Доступ открыт");
                    }
                    else
                    {
                        Console.WriteLine("Неверно (логин или пароль)");
                    }
                }
            }
            else if (a1 == 9)
            {
                Console.Clear();
                string filePath = "f2.txt";
                int count = 0;

                string content = File.ReadAllText(filePath);
                string[] numbers = content.Split(' ', (char)StringSplitOptions.RemoveEmptyEntries);

                foreach (string number in numbers)
                {
                    if (int.TryParse(number, out int value) && value < 0)
                    {
                        count++;
                    }
                }

                Console.WriteLine($"Количество отрицательных чисел: {count}");
            }
            else if (a1 == 10)
            {
                Console.Clear();
                string filePath = "f4.txt";
                string[] numbers = File.ReadAllLines(filePath);
                int count = 0;

                foreach (string line in numbers)
                {
                    string[] values = line.Split(' ', (char)StringSplitOptions.RemoveEmptyEntries);
                    foreach (string value in values)
                    {
                        if (int.TryParse(value, out int number) && number > 10)
                        {
                            Console.WriteLine(number);
                            count++;
                        }
                    }
                }

                Console.WriteLine($"Количество чисел больше 10: {count}");
            }
            else if (a1 == 11)
            {
                Console.Clear();
                string filePath = "f5.txt";
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    string[] numbers = line.Split(' ');

                    foreach (string number in numbers)
                    {
                        int sum = 0;
                        foreach (char digit in number)
                        {
                            if (char.IsDigit(digit))
                            {
                                sum += (int)char.GetNumericValue(digit);
                            }
                        }
                        Console.WriteLine($"Сумма цифр числа {number}: {sum}");
                    }
                }
            }
            else if (a1 == 12)
            {
                string filePath = "text.txt";
                int countD = 0;


                using (FileStream fs = new FileStream(filePath, FileMode.Open))
                {
                    int byteRead;
                    while ((byteRead = fs.ReadByte()) != -1)
                    {
                        char character = (char)byteRead;
                        if (character == 'D')
                        {
                            countD++;
                        }
                    }
                }

                Console.WriteLine($"Количество букв 'D': {countD}");
            }
            else if (a1 == 13)
            {
                Console.Clear();
                string filePath = "text.txt";
                string[] lines = File.ReadAllLines(filePath);

                foreach (string line in lines)
                {
                    Console.WriteLine($"Количество символов в строке: {line.Length}");
                }
            }
            else if (a1 == 14)
            {
                Console.Clear();
                Console.Write("Введите имя или путь к файлу: ");
                string filePath = Console.ReadLine();

                try
                {
                    string content = File.ReadAllText(filePath);
                    Console.WriteLine(content);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                }
            }
            else if (a1 == 15)
            {
                string filePath = "random_numbers.txt";
                Random random = new Random();
                List<int> numbers = new List<int>();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    for (int i = 0; i < 10; i++)
                    {
                        int number = random.Next(-60, 71);
                        writer.WriteLine(number);
                        numbers.Add(number);
                    }
                }

                int min = int.MaxValue;
                int max = int.MinValue;

                foreach (int number in numbers)
                {
                    if (number < min) min = number;
                    if (number > max) max = number;
                }
                Console.WriteLine($"Минимальное значение: {min}, Максимальное значение: {max}");
            }
            else if (a1 == 16)
            {
                string filePath = "random_numbers.txt";
                string positiveFilePath = "positive_numbers.txt";
                Random random = new Random();

                using (StreamWriter writer = new StreamWriter(filePath))
                {
                    for (int i = 0; i < 10; i++)
                    {
                        int number = random.Next(-50, 66);
                        writer.Write(number + " ");
                    }
                }

                using (StreamReader reader = new StreamReader(filePath))
                using (StreamWriter positiveWriter = new StreamWriter(positiveFilePath))
                {
                    string content = reader.ReadLine();
                    string[] numbers = content.Split(' ');

                    foreach (string number in numbers)
                    {
                        if (int.TryParse(number, out int value) && value > 0)
                        {
                            positiveWriter.Write(value + " ");
                        }
                    }
                }
            }
            else if (a1 == 17)
            {
                Console.Clear();
                string filePath = "lines.txt";
                List<string> lines = new List<string>(File.ReadAllLines(filePath));

                Console.Write("Введите номер строки для изменения (начиная с 1): ");
                int lineNumber = int.Parse(Console.ReadLine()) - 1;

                if (lineNumber >= 0 && lineNumber < lines.Count)
                {
                    Console.Write("Введите новый текст: ");
                    lines[lineNumber] = Console.ReadLine();

                    File.WriteAllLines(filePath, lines);
                    Console.WriteLine("Строка изменена успешно.");
                }
                else
                {
                    Console.WriteLine("Некорректный номер строки.");
                }
            }
        }
    }
}
