﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WorkDB_Shengals
{
    public partial class Admin_frm : Form
    {
        SqlDataAdapter adptr;
        DataTable table;
        public void UpdateData()
        {
            Validation.UpdateData(user_tblDataGridView);
        }
        public void AddRow(string log, string pass, string role)
        {
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string findconnetion = $"Select * from User_tbl where Login = '{log}'";
            string query = $"Insert into dbo.User_tbl (Login, Password, Count, Date, Active, Role)\r\nvalues ('{log}', '{pass}', '0', '2025-05-1', 'True', '{role}')";
            using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();
                SqlCommand datereader = new SqlCommand(findconnetion, connection);
                SqlDataReader reader = datereader.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    if (reader["Login"].ToString() == log)
                    {
                        MessageBox.Show("Такое имя уже есть введите другое");
                    }

                }
                else
                {
                    using (SqlConnection connecta = new SqlConnection(connect))
                    {
                        connecta.Open();
                        SqlCommand command = new SqlCommand(query, connecta);
                        int number = command.ExecuteNonQuery();
                        MessageBox.Show($"Добавлено объектов: {number}");
                    }
                }
            }
        }
        private void ToggleBlockSelectedUser()
        {
            if (user_tblDataGridView.CurrentCell == null)
            {
                MessageBox.Show("Выберите пользователя");
                return;
            }

            int rowIndex = user_tblDataGridView.CurrentCell.RowIndex;
            int id = Convert.ToInt32(user_tblDataGridView.Rows[rowIndex].Cells[0].Value);
            bool currentActive = Convert.ToBoolean(user_tblDataGridView.Rows[rowIndex].Cells[5].Value);

            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string query = "UPDATE User_tbl SET Active = @Active WHERE ID = @ID";

            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@Active", !currentActive);
                    command.Parameters.AddWithValue("@ID", id);

                    int rowsAffected = command.ExecuteNonQuery();
                    if (rowsAffected > 0)
                    {
                        MessageBox.Show($"Пользователь успешно {(currentActive ? "заблокирован" : "разблокирован")}");
                        RefreshData();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при изменении статуса блокировки: {ex.Message}");
            }
        }

        private void ShowBlockedUsers()
        {
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string query = "SELECT * FROM User_tbl WHERE Active = 0";

            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    user_tblDataGridView.DataSource = table;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        private void UnblockAllUsers()
        {
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string query = "UPDATE User_tbl SET Active = 1";

            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    int rowsAffected = command.ExecuteNonQuery();
                    MessageBox.Show($"Разблокировано {rowsAffected} пользователей");
                    RefreshData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при разблокировке пользователей: {ex.Message}");
            }
        }

        private void BlockUsersByLoginDate(DateTime from, DateTime to)
        {
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string query = @"UPDATE User_tbl 
                   SET Active = 0 
                   WHERE Date NOT BETWEEN @From AND @To";

            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(query, connection);
                    command.Parameters.AddWithValue("@From", from);
                    command.Parameters.AddWithValue("@To", to.AddDays(1).AddSeconds(-1)); // Конец дня

                    int rowsAffected = command.ExecuteNonQuery();
                    MessageBox.Show($"Заблокировано {rowsAffected} пользователей");
                    RefreshData();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при блокировке по дате: {ex.Message}");
            }
        }

        private void ShowUsersLoggedInToday()
        {
            DateTime today = DateTime.Today;
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string query = "SELECT * FROM User_tbl WHERE CONVERT(date, Date) = @Today";

            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    adapter.SelectCommand.Parameters.AddWithValue("@Today", today);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    user_tblDataGridView.DataSource = table;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }

        public void RefreshData()
        {
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string query = "SELECT * FROM User_tbl";

            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    SqlDataAdapter adapter = new SqlDataAdapter(query, connection);
                    DataTable table = new DataTable();
                    adapter.Fill(table);
                    user_tblDataGridView.DataSource = table;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}");
            }
        }
        public Admin_frm()
        {
            InitializeComponent();

            InitializeCustomComponents();
            dtpFrom.Value = DateTime.Today.AddMonths(-1);
            dtpTo.Value = DateTime.Today;

            RefreshData();
        }

        private void InitializeCustomComponents()
        {
            // Проверяем существование элементов перед доступом
            if (dtpFrom != null && dtpTo != null)
            {
                dtpFrom.Value = DateTime.Today.AddMonths(-1);
                dtpTo.Value = DateTime.Today;
            }
            else
            {
                MessageBox.Show("Элементы выбора даты не инициализированы");
            }

            SafeRefreshData();
        }
        private void SafeRefreshData()
        {
            try
            {
                if (user_tblDataGridView != null)
                {
                    RefreshData();
                }
                else
                {
                    MessageBox.Show("DataGridView не инициализирован");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при загрузке данных: {ex.Message}");
            }
        }
        private void Admin_frm_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }
        private void btnBlockUser_Click(object sender, EventArgs e)
        {
            ToggleBlockSelectedUser();
        }

        private void btnShowBlocked_Click(object sender, EventArgs e)
        {
            ShowBlockedUsers();
        }

        private void btnUnblockAll_Click(object sender, EventArgs e)
        {
            UnblockAllUsers();
        }

        private void btnBlockByDate_Click(object sender, EventArgs e)
        {
            DateTime from = dtpFrom.Value;
            DateTime to = dtpTo.Value;
            BlockUsersByLoginDate(from, to);
        }

        private void btnShowToday_Click(object sender, EventArgs e)
        {
            ShowUsersLoggedInToday();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            RefreshData();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            string log = Log_Txt.Text;
            string pass = Pass_Txt.Text;
            string role = Role_Txt.Text;
            Validation.Valadmin(log, pass, role);
            string d = Validation.Valadmin(log, pass, role);
            if (d == "0")
            {
                AddRow(log, pass, role);
                UpdateData();
            }
            else
            {
                switch (d)
                {
                    case "1":
                        MessageBox.Show("Ошибка, логин не может быть пустым");
                        break;
                    case "2":
                        MessageBox.Show("Ошибка, пароль не может быть пустым");
                        break;
                    case "3":
                        MessageBox.Show("Ошибка, роль не может быть пустой");
                        break;
                    case "4":
                        MessageBox.Show("Ошибка, роль не может быть другого типа кроме как User или Admin");
                        break;
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string log = IzmLog_Txt.Text;
            string pass = IzmPass_Txt.Text;
            string role = IzmRol_Txt.Text;
            int rowIndex = user_tblDataGridView.CurrentCell.RowIndex;
            int id = Convert.ToInt32(user_tblDataGridView.Rows[rowIndex].Cells[0].Value);
            Validation.Valadmin(log, pass, role);
            string d = Validation.Valadmin(log, pass, role);
            if (d == "0")
            {
                UpdateData();
            }
            else
            {
                switch (d)
                {
                    case "1":
                        MessageBox.Show("Ошибка, логин не может быть пустым");
                        break;
                    case "2":
                        MessageBox.Show("Ошибка, пароль не может быть пустым");
                        break;
                    case "3":
                        MessageBox.Show("Ошибка, роль не может быть пустой");
                        break;
                    case "4":
                        MessageBox.Show("Ошибка, роль не может быть другого типа кроме как User или Admin");
                        break;
                }
            }
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string updateQuery = @"UPDATE User_tbl SET Login = @Login, Password = @Password, Role = @Role WHERE ID = @ID";

            try
            {
                using (SqlConnection connection = new SqlConnection(connect))
                {
                    connection.Open();

                    string checkLoginQuery = "SELECT COUNT(*) FROM User_tbl WHERE Login = @Login AND ID != @ID";
                    using (SqlCommand checkCommand = new SqlCommand(checkLoginQuery, connection))
                    {
                        checkCommand.Parameters.AddWithValue("@Login", log);
                        checkCommand.Parameters.AddWithValue("@ID", id);

                        int existingCount = (int)checkCommand.ExecuteScalar();
                        if (existingCount > 0)
                        {
                            MessageBox.Show("Пользователь с таким логином уже существует");
                            return;
                        }
                    }

                    using (SqlCommand updateCommand = new SqlCommand(updateQuery, connection))
                    {
                        updateCommand.Parameters.AddWithValue("@Login", log);
                        updateCommand.Parameters.AddWithValue("@Password", pass);
                        updateCommand.Parameters.AddWithValue("@Role", role);
                        updateCommand.Parameters.AddWithValue("@ID", id);

                        int rowsAffected = updateCommand.ExecuteNonQuery();

                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Данные успешно обновлены");
                            UpdateData();
                        }
                        else
                        {
                            MessageBox.Show("Не удалось обновить данные. Пользователь не найден.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении данных: {ex.Message}");
            }
        }

        private void user_tblDataGridView_SelectionChanged(object sender, EventArgs e)
        {
            int rowIndex = user_tblDataGridView.CurrentCell.RowIndex;
            if (user_tblDataGridView.CurrentCell != null)
            {
                IzmLog_Txt.Text = user_tblDataGridView.Rows[rowIndex].Cells[1].Value.ToString();
                IzmPass_Txt.Text = user_tblDataGridView.Rows[rowIndex].Cells[2].Value.ToString();
                IzmRol_Txt.Text = user_tblDataGridView.Rows[rowIndex].Cells[6].Value.ToString();
            }
        }
    }
}
