﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace _15_pract
{
    public partial class Form1 : Form
    {
        private SubjectIndex subjectIndex;
        public Form1()
        {
            InitializeComponent();
            subjectIndex = new SubjectIndex();
        }


        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                string word = textBox1.Text;
                int pageNumber = int.Parse(textBox2.Text);
                subjectIndex.AddEntry(word, pageNumber);
                richTextBox1.Text = "Запись добавлена.";
            }
            catch (Exception ex)
            {
                richTextBox1.Text = $"Ошибка: {ex.Message}";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string word = textBox1.Text;
                subjectIndex.RemoveEntry(word);
                richTextBox1.Text = "Запись удалена.";
            }
            catch (Exception ex)
            {
                richTextBox1.Text = $"Ошибка: {ex.Message}";
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            richTextBox1.Text = subjectIndex.PrintIndex();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            string word = textBox1.Text;
            richTextBox1.Text = subjectIndex.PrintPagesForWord(word);
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog openFileDialog = new OpenFileDialog();
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    subjectIndex.LoadFromFile(openFileDialog.FileName);
                    richTextBox1.Text = "Данные загружены из файла.";
                }
            }
            catch (Exception ex)
            {
                richTextBox1.Text = $"Ошибка: {ex.Message}";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                SaveFileDialog saveFileDialog = new SaveFileDialog();
                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    subjectIndex.SaveToFile(saveFileDialog.FileName);
                    richTextBox1.Text = "Данные сохранены в файл.";
                }
            }
            catch (Exception ex)
            {
                richTextBox1.Text = $"Ошибка: {ex.Message}";
            }
        }
    }
}
