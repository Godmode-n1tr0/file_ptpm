﻿namespace pract13._1
{
    using Monstr;
    Monstr Hero1 = new Monstr();
    public class Class1
    {

    }
}
