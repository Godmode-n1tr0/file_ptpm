﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WorkDB_Shengals
{
    public partial class UpdatePass : Form
    {

        public void Checker(string pass, string Valpass)
        {
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string findconnetion = $"Select * from User_tbl where Password = '{textBox1.Text}'";
            string updateQuery = $"UPDATE User_tbl SET Password = '{pass}' WHERE ID = 2;";
            using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(findconnetion, connection);
                SqlDataReader reader = command.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    if (reader["Password"].ToString() == textBox1.Text)
                    {
                        reader.Close();
                        SqlCommand Ucommand = new SqlCommand(updateQuery, connection);
                        command.Parameters.AddWithValue(pass, pass);
                        int check = Ucommand.ExecuteNonQuery();
                        if (check > 0)
                        {
                            this.Hide();
                            Root_frm Root = new Root_frm();
                            Root.Show();
                        }
                        else
                        {
                            MessageBox.Show("User с ID 2 не найден");
                        }
                    }
                    else
                    {
                        MessageBox.Show("Текущий пароль не верный");
                    }
                }
            }
        }
        public UpdatePass()
        {
            InitializeComponent();
        }

        private void UpdatePass_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string pass = textBox3.Text;
            string Valpass = textBox2.Text;
            Validation.ValPass(pass, Valpass);
            string d = Validation.ValPass(pass, Valpass);
            if (d == "0")
            {
                Checker(pass, Valpass);
            }
            else
            {
                switch (d)
                {
                    case "1":
                        MessageBox.Show("Ошибка, пароль не может быть пустым");
                        break;
                    case "2":
                        MessageBox.Show("Ошибка, подтверждающий пароль не может быть пустым");
                        break;
                    case "3":
                        MessageBox.Show("Ошибка, пароли не совпадают");
                        break;
                }
            }
        }
    }
}
