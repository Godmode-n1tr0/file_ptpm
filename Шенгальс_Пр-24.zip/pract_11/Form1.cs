﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract_11
{
    public partial class Form1 : Form
    {
        int t = 0;
        PictureBox pic1 = new PictureBox();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            timer1.Stop();
        }
        private void timer1_Tick(object sender, EventArgs e)
        {
            t++;
            if (t <= 5)
            {
                panel1.BackColor = Color.Red;
                panel2.BackColor = Color.Black;
                panel3.BackColor = Color.Black;
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 400;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 10)
            {
                panel1.BackColor = Color.Red;
                panel2.BackColor = Color.Black;
                panel3.BackColor = Color.Black;
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 500;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 15)
            {
                panel1.BackColor = Color.Red;
                panel2.BackColor = Color.Black;
                panel3.BackColor = Color.Black;
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 600;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 20)
            {
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 700;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 25)
            {
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 0;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 30)
            {
                panel1.BackColor = Color.Black;
                panel2.BackColor = Color.Orange;
                panel3.BackColor = Color.Black;
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 100;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 35)
            {
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 200;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 40)
            {
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 300;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }
            else if (t <= 45)
            {
                panel1.BackColor = Color.Black;
                panel2.BackColor = Color.Black;
                panel3.BackColor = Color.Green;
                t = 0;
                timer1.Stop();
                if (this.Width > pic1.Left)
                {
                    pic1.Left = 400;
                }
                else
                {
                    pic1.Left = -pic1.Width;
                }
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Controls.Add(pic1);
            pic1.Location = new Point(300, 250);
            pic1.SizeMode = PictureBoxSizeMode.StretchImage;
            if (File.Exists("kaef.jpg"))
            {
                pic1.Image = Image.FromFile("kaef.jpg");
            }
        }
    }
}
