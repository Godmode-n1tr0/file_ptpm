﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_2._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите номер задания: ");
            int a1 = Convert.ToInt32(Console.ReadLine());
            if (a1 == 1)
            {
                Console.Clear();
                string filePath = "example.txt";

                try
                {
                    string content = File.ReadAllText(filePath);

                    int spaceIndex = content.IndexOf(' ');

                    if (spaceIndex != -1)
                    {
                        string newContent = content.Substring(spaceIndex + 1);

                        File.WriteAllText(filePath, newContent);
                        Console.WriteLine("Содержимое файла обновлено.");
                    }
                    else
                    {
                        Console.WriteLine("Пробел не найден в файле.");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Произошла ошибка: {ex.Message}");
                }
            }
            else if (a1 == 2)
            {
                string filePath = "numbers.txt"; 
                int count = 0;
                double sum = 0;

                try
                {
                    string[] lines = File.ReadAllLines(filePath);

                    foreach (string line in lines)
                    {
                        string trimmedLine = line.Trim();

                        if (double.TryParse(trimmedLine, NumberStyles.Float, CultureInfo.InvariantCulture, out double number))
                        {
                            if (number % 1 != 0)
                            {
                                count++;
                                sum += number;
                            }
                        }
                    }

                    Console.WriteLine($"Количество чисел с ненулевой дробной частью: {count}");
                    Console.WriteLine($"Сумма чисел с ненулевой дробной частью: {sum}");
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Произошла ошибка: {ex.Message}");
                }
            }
        }
    }
}
