﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract9_Shengals_Roman
{
    public partial class Form1 : Form
    {
        private List<Human> human = new List<Human>();
        private List<string> list_students = new List<string>();
        public Form1()
        {
            InitializeComponent();
            listBox1.DataSource = Human.human;
        }

        private void UpdateListBox()
        {
            listBox1.DataSource = null;
            listBox1.DataSource = Human.human;
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            var selectedHuman = Human.human[listBox1.SelectedIndex];
            textBox1.Text = selectedHuman.Surname;
            textBox2.Text = selectedHuman.Name;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text) || string.IsNullOrWhiteSpace(textBox2.Text))
            {
                MessageBox.Show("Заполните фамилию и имя!");
                return;
            }
            Human newHuman = new Human
            {
                Surname = textBox1.Text.Trim(),
                Name = textBox2.Text.Trim()
            };
            if (!Human.human.Contains(newHuman))
            {
                Human.human.Add(newHuman);
                UpdateListBox();
            }
            else
            {
                MessageBox.Show("Такой студент уже есть в списке!");
            }
        }

        private void btnEdit_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1)
            {
                MessageBox.Show("Выберите элемент для редактирования!");
                return;
            }
            int index = listBox1.SelectedIndex;
            Human.human[index] = new Human
            {
                Surname = textBox1.Text.Trim(),
                Name = textBox2.Text.Trim()
            };
            UpdateListBox();
        }

        private void btnDelete_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            Human.human.RemoveAt(listBox1.SelectedIndex);
            UpdateListBox();
        }

        private void btnInsert_Click_1(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            int index = listBox1.SelectedIndex;
            Human newHuman = new Human
            {
                Surname = textBox1.Text.Trim(),
                Name = textBox2.Text.Trim()
            };
            if (!Human.human.Contains(newHuman))
            {
                Human.human.Insert(index, newHuman);
                UpdateListBox();
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Human.human.Clear();
            UpdateListBox();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            Human.human.Sort((a, b) => a.ToString().CompareTo(b.ToString()));
            UpdateListBox();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                Human.SaveToFile(textBox3.Text);
                MessageBox.Show("Данные сохранены!");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                Human.LoadFromFile(textBox3.Text);
                UpdateListBox();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            int index = listBox1.SelectedIndex;
            if (index == Human.human.Count - 1) index = 0;
            else index++;
            listBox1.SelectedIndex = index;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == -1) return;
            int index = listBox1.SelectedIndex;
            if (index == 0) index = Human.human.Count - 1;
            else index--;
            listBox1.SelectedIndex = index;
        }
    }
}
