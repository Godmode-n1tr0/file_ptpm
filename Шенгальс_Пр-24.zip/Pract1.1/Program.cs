﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Pract1._1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите номер задания: ");
            int a1 = Convert.ToInt32(Console.ReadLine());
            if (a1 == 1)
            {
                Console.Clear();
                File.WriteAllText("hello.txt", "hello world");
            }
            else if (a1 == 2)
            {
                Console.Clear();
                using (StreamWriter writer = new StreamWriter("file1.txt"))
                {
                    writer.WriteLine("Шенгальс");
                    writer.WriteLine("Роман");
                    writer.WriteLine("2007");
                }
            }
            else if (a1 == 3)
            {
                Console.Clear();
                int age = 17;
                string group = "ПР-24";

                using (StreamWriter writer = new StreamWriter("file1.txt", true))
                {
                    writer.WriteLine($"Возраст: {age}");
                    writer.WriteLine($"Группа: {group}");
                }
            }
            else if (a1 == 4)
            {
                Console.Clear();
                Console.Write("Введите ФИО: ");
                string fullName = Console.ReadLine();

                using (StreamWriter writer = new StreamWriter("file2.txt"))
                {
                    writer.WriteLine(fullName);
                }
            }
            else if (a1 == 5)
            {
                Console.Clear();
                Console.Write("Введите ФИО: ");
                string fullName = Console.ReadLine();

                using (StreamWriter writer1 = new StreamWriter("file2.txt"))
                {
                    writer1.WriteLine(fullName);
                }

                using (StreamWriter writer2 = new StreamWriter("file2_add.txt", true))
                {
                    writer2.WriteLine(fullName);
                }
            }
            else if (a1 == 6)
            {
                Console.Clear();
                Console.Write("Введите ФИО: ");
                string fullName = Console.ReadLine();

                Console.Write("Введите день рождения: ");
                int day = int.Parse(Console.ReadLine());

                Console.Write("Введите месяц рождения: ");
                int month = int.Parse(Console.ReadLine());

                using (StreamWriter writer = new StreamWriter("file2.txt", true))
                {
                    writer.WriteLine(fullName);
                    writer.WriteLine($"День: {day}\nМесяц: {month}");
                }
            }
            else if (a1 == 7)
            {
                Console.Clear();
                Console.Write("Введите первое число: ");
                int firstNumber = int.Parse(Console.ReadLine());

                Console.Write("Введите второе число: ");
                int secondNumber = int.Parse(Console.ReadLine());

                int sum = firstNumber + secondNumber;

                using (StreamWriter writer = new StreamWriter("file3.txt", true))
                {
                    writer.WriteLine($"{firstNumber}+{secondNumber}={sum}");
                }
            }
            else if (a1 == 8)
            {
                Console.Clear();
                Console.Write("Введите имя пользователя: ");
                string username = Console.ReadLine();

                Console.Write("Введите пароль: ");
                string password = Console.ReadLine();

                using (StreamWriter writer = new StreamWriter("file4.txt"))
                {
                    writer.WriteLine($"Имя пользователя: {username}");
                    writer.WriteLine($"Пароль: {password}");
                }
            }
            else if (a1 == 9)
            {
                Console.Clear();
                string[] adjectives = { "Голодный", "Смелый", "Добрый", "Злой", "Мудрый", "Быстрый", "Сильный", "Слабый", "Храбрый", "Мрачный", "Весёлый", "Тихий", "Шумный", "Могучий", "Отважный" };

                string[] heroes = { "Рыцарь", "Дракон", "Волшебник", "Лучник", "Герой", "Король", "Принцесса", "Злодей", "Наёмник", "Маг", "Воин", "Творец", "Спаситель", "Призрак", "Супергерой" };

                Random random = new Random();
                using (StreamWriter writer = new StreamWriter("file5.txt"))
                {
                    for (int i = 0; i < 25; i++)
                    {
                        string adjective = adjectives[random.Next(adjectives.Length)];
                        string hero = heroes[random.Next(heroes.Length)];
                        writer.WriteLine($"{adjective} {hero}");
                    }
                }
            }
            else if (a1 == 10)
            {
                Console.Clear();
                using (StreamWriter writer = new StreamWriter("file6.txt", true))
                {
                    while (true)
                    {
                        Console.Write("Введите ФИО или введите 'СТОП' для завершения: ");
                        string fullName = Console.ReadLine();

                        if (fullName.ToUpper() == "СТОП")
                        {
                            break;
                        }

                        writer.WriteLine(fullName);
                    }
                }
            }
        }
    }
}
