﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pract_20_1
{
    public partial class Form1 : Form
    {
        private int currentShowId = -1;

        public Form1()
        {
            InitializeComponent();
            InitializeForm();
            this.dataGridView1.SelectionChanged += new System.EventHandler(this.dataGridView1_SelectionChanged);
        }

        private void InitializeForm()
        {
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            tabControl1.SelectedIndex = 0;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                ShowGroupBox(groupBox1);
            }
            else if (comboBox1.SelectedIndex == 1)
            {
                ShowGroupBox(groupBox2);
            }
        }

        private void ShowGroupBox(GroupBox groupBox)
        {
            label1.Visible = false;
            comboBox1.Visible = false;
            button1.Visible = false;
            groupBox.Visible = true;
            groupBox.BringToFront();
        }

        private void LoadShows(string showType)
        {
            try
            {
                string query = showType == "Tour" ?
                    @"SELECT s.Id, s.Title, s.Genre, s.Author, s.Director, 
                             t.TourStart, t.TourEnd, t.Venue
                      FROM Shows s
                      JOIN TourShows t ON s.Id = t.ShowId" :
                    @"SELECT s.Id, s.Title, s.Genre, s.Author, s.Director, 
                             l.TheaterName, l.PerformancesPerSeason
                      FROM Shows s
                      JOIN LocalShows l ON s.Id = l.ShowId";

                dataGridView1.DataSource = DatabaseHelper.GetDataTable(query);
                dataGridView1.Columns["Id"].Visible = false;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки данных: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                string title = textBox1.Text;
                string genre = comboBox2.Text;
                string author = textBox2.Text;
                string director = textBox3.Text;
                DateTime tourStart = DateTime.ParseExact(textBox4.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture);
                DateTime tourEnd = DateTime.ParseExact(textBox5.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture);
                string venue = comboBox3.Text;

                // Валидация
                var spectacle = new GSpectacl(title, genre, author, director, tourStart, tourEnd, venue, true);

                // Сохранение в БД
                int showId = SaveShowToDatabase("Tour", title, genre, author, director);
                SaveTourShow(showId, tourStart, tourEnd, venue);

                MessageBox.Show("Гастрольный спектакль сохранен!");
                ResetForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private int SaveShowToDatabase(string showType, string title, string genre, string author, string director)
        {
            string query = @"INSERT INTO Shows (ShowType, Title, Genre, Author, Director) 
                             OUTPUT INSERTED.ID
                             VALUES (@type, @title, @genre, @author, @director)";

            var parameters = new[]
            {
                new SqlParameter("@type", showType),
                new SqlParameter("@title", title),
                new SqlParameter("@genre", genre),
                new SqlParameter("@author", author),
                new SqlParameter("@director", director)
            };

            return DatabaseHelper.ExecuteScalar<int>(query, parameters);
        }

        private void SaveTourShow(int showId, DateTime tourStart, DateTime tourEnd, string venue)
        {
            string query = @"INSERT INTO TourShows (ShowId, TourStart, TourEnd, Venue) 
                             VALUES (@showId, @start, @end, @venue)";

            var parameters = new[]
            {
                new SqlParameter("@showId", showId),
                new SqlParameter("@start", tourStart),
                new SqlParameter("@end", tourEnd),
                new SqlParameter("@venue", venue)
            };

            DatabaseHelper.ExecuteCommand(query, parameters);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                string title = textBox6.Text;
                string genre = comboBox5.Text;
                string author = textBox8.Text;
                string director = textBox10.Text;
                string theater = comboBox4.Text;
                int performances = int.Parse(textBox7.Text);

                // Валидация
                var spectacle = new MSpectacl(title, genre, author, director, theater, performances);

                // Сохранение в БД
                int showId = SaveShowToDatabase("Local", title, genre, author, director);
                SaveLocalShow(showId, theater, performances);

                MessageBox.Show("Местный спектакль сохранен!");
                ResetForm();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void SaveLocalShow(int showId, string theater, int performances)
        {
            string query = @"INSERT INTO LocalShows (ShowId, TheaterName, PerformancesPerSeason) 
                             VALUES (@showId, @theater, @performances)";

            var parameters = new[]
            {
                new SqlParameter("@showId", showId),
                new SqlParameter("@theater", theater),
                new SqlParameter("@performances", performances)
            };

            DatabaseHelper.ExecuteCommand(query, parameters);
        }

        private void ResetForm()
        {
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
            comboBox1.SelectedIndex = -1;
        }

        private void button4_Click(object sender, EventArgs e) => ResetForm();
        private void button5_Click(object sender, EventArgs e) => ResetForm();

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите спектакль для удаления");
                return;
            }

            int id = (int)dataGridView1.SelectedRows[0].Cells["Id"].Value;

            if (MessageBox.Show("Удалить выбранный спектакль?", "Подтверждение",
                MessageBoxButtons.YesNo) == DialogResult.Yes)
            {
                try
                {
                    string query = "DELETE FROM Shows WHERE Id = @id";
                    var parameter = new SqlParameter("@id", id);
                    DatabaseHelper.ExecuteCommand(query, parameter);

                    LoadShows(comboBox6.SelectedIndex == 0 ? "Tour" : "Local");
                    MessageBox.Show("Спектакль удален!");
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Ошибка при удалении: {ex.Message}");
                }
            }
        }

        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox6.SelectedIndex == 0)
            {
                groupBox4.Visible = false;
                LoadShows("Tour");
                groupBox3.Visible = true;
            }
            else if (comboBox6.SelectedIndex == 1)
            {
                groupBox3.Visible = false;
                LoadShows("Local");
                groupBox4.Visible = true;
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0) return;

            DataGridViewRow row = dataGridView1.SelectedRows[0];
            currentShowId = (int)row.Cells["Id"].Value;

            if (comboBox6.SelectedIndex == 0) // Гастрольный
            {
                textBox12.Text = row.Cells["Title"].Value.ToString();
                textBox13.Text = row.Cells["Genre"].Value.ToString();
                textBox14.Text = row.Cells["Author"].Value.ToString();
                textBox15.Text = row.Cells["Director"].Value.ToString();
                textBox17.Text = ((DateTime)row.Cells["TourStart"].Value).ToString("dd.MM.yyyy");
                textBox16.Text = ((DateTime)row.Cells["TourEnd"].Value).ToString("dd.MM.yyyy");
                textBox18.Text = row.Cells["Venue"].Value.ToString();
            }
            else // Местный
            {
                textBox20.Text = row.Cells["Title"].Value.ToString();
                textBox19.Text = row.Cells["Genre"].Value.ToString();
                textBox22.Text = row.Cells["Author"].Value.ToString();
                textBox24.Text = row.Cells["Director"].Value.ToString();
                textBox23.Text = row.Cells["TheaterName"].Value.ToString();
                textBox25.Text = row.Cells["PerformancesPerSeason"].Value.ToString();
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (currentShowId == -1) return;

            try
            {
                UpdateTourShow(
                    currentShowId,
                    textBox12.Text,
                    textBox13.Text,
                    textBox14.Text,
                    textBox15.Text,
                    DateTime.ParseExact(textBox17.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture),
                    DateTime.ParseExact(textBox16.Text, "dd.MM.yyyy", CultureInfo.InvariantCulture),
                    textBox18.Text
                );

                MessageBox.Show("Гастрольный спектакль обновлен!");
                LoadShows("Tour");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void UpdateTourShow(int id, string title, string genre, string author, string director,
                                   DateTime tourStart, DateTime tourEnd, string venue)
        {
            // Валидация
            new GSpectacl(title, genre, author, director, tourStart, tourEnd, venue, true);

            // Обновление основной таблицы
            string updateShow = @"UPDATE Shows SET 
                                Title = @title, 
                                Genre = @genre, 
                                Author = @author, 
                                Director = @director 
                                WHERE Id = @id";

            DatabaseHelper.ExecuteCommand(updateShow, new[]
            {
                new SqlParameter("@title", title),
                new SqlParameter("@genre", genre),
                new SqlParameter("@author", author),
                new SqlParameter("@director", director),
                new SqlParameter("@id", id)
            });

            // Обновление таблицы гастролей
            string updateTour = @"UPDATE TourShows SET 
                                TourStart = @start, 
                                TourEnd = @end, 
                                Venue = @venue 
                                WHERE ShowId = @id";

            DatabaseHelper.ExecuteCommand(updateTour, new[]
            {
                new SqlParameter("@start", tourStart),
                new SqlParameter("@end", tourEnd),
                new SqlParameter("@venue", venue),
                new SqlParameter("@id", id)
            });
        }

        private void button9_Click(object sender, EventArgs e)
        {
            if (currentShowId == -1) return;

            try
            {
                UpdateLocalShow(
                    currentShowId,
                    textBox20.Text,
                    textBox19.Text,
                    textBox22.Text,
                    textBox24.Text,
                    textBox23.Text,
                    int.Parse(textBox25.Text)
                );

                MessageBox.Show("Местный спектакль обновлен!");
                LoadShows("Local");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void UpdateLocalShow(int id, string title, string genre, string author,
                                    string director, string theater, int performances)
        {
            // Валидация
            new MSpectacl(title, genre, author, director, theater, performances);

            // Обновление основной таблицы
            string updateShow = @"UPDATE Shows SET 
                                Title = @title, 
                                Genre = @genre, 
                                Author = @author, 
                                Director = @director 
                                WHERE Id = @id";

            DatabaseHelper.ExecuteCommand(updateShow, new[]
            {
                new SqlParameter("@title", title),
                new SqlParameter("@genre", genre),
                new SqlParameter("@author", author),
                new SqlParameter("@director", director),
                new SqlParameter("@id", id)
            });

            // Обновление таблицы местных спектаклей
            string updateLocal = @"UPDATE LocalShows SET 
                                TheaterName = @theater, 
                                PerformancesPerSeason = @performances 
                                WHERE ShowId = @id";

            DatabaseHelper.ExecuteCommand(updateLocal, new[]
            {
                new SqlParameter("@theater", theater),
                new SqlParameter("@performances", performances),
                new SqlParameter("@id", id)
            });
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string searchText = textBox9.Text.Trim().ToLower();

            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                bool visible = false;
                foreach (DataGridViewCell cell in row.Cells)
                {
                    if (cell.Value != null &&
                        cell.Value.ToString().ToLower().Contains(searchText))
                    {
                        visible = true;
                        break;
                    }
                }
                row.Visible = visible;
            }
        }
    }
}
