﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Design;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace pract7
{
    public partial class Form1 : Form
    {
        int count = 0;
        TableLayoutPanel table;
        int record = 0;
        Label firstClicked = null;
        Label secondClicked = null;
        Random random = new Random();
        string nickname = "";
        int index = 0;
        List<string> icons;
        int size = 24;
        private void Lcons()
        {
            if (index == 1)
            {
                icons = new List<string>()
                {
                    "q", "q", "w", "w", "e", "e", "r", "r",
                    "t", "t", "y", "y", "u", "u", "i", "i"
                };
            }
            if (index == 2)
            {
                icons = new List<string>()
                {
                    "q", "q", "w", "w", "e", "e", "r", "r",
                    "t", "t", "y", "y", "u", "u", "i", "i",
                    "o", "o", "p", "p", "a", "a", "s", "s",
                    "d", "d", "f", "f", "g", "g", "h", "h",
                    "j", "j", "k", "k"
                };
            }
            if (index == 3)
            {
                icons = new List<string>()
                {
                    "q", "q", "w", "w", "e", "e", "r", "r",
                    "t", "t", "y", "y", "u", "u", "i", "i",
                    "o", "o", "p", "p", "a", "a", "s", "s",
                    "d", "d", "f", "f", "g", "g", "h", "h",
                    "j", "j", "k", "k", "l", "l", "z", "z",
                    "x", "x", "c", "c", "v", "v", "b", "b",
                    "n", "n", "m", "m", ",", ",", ".", ".",
                    "!", "!", "@", "@", "#", "#", "$", "$"
                };
            }
            if (index == 4)
            {
                icons = new List<string>()
                {
                    "q", "q", "w", "w", "e", "e", "r", "r",
                    "t", "t", "y", "y", "u", "u", "i", "i",
                    "o", "o", "p", "p", "a", "a", "s", "s",
                    "d", "d", "f", "f", "g", "g", "h", "h",
                    "j", "j", "k", "k", "l", "l", "z", "z",
                    "x", "x", "c", "c", "v", "v", "b", "b",
                    "n", "n", "m", "m", ",", ",", ".", ".",
                    "!", "!", "@", "@", "#", "#", "$", "$",
                    "%", "%", "^", "^", "й", "й", "ц", "ц",
                    "у", "у", "к", "к", "а", "а", "е", "е",
                    "&", "&", "*", "*", "/", "/", "7", "7",
                    "н", "н", "г", "г", "ш", "ш", ";", ";",
                    "'", "'", "я", "я"
                };
            }
        }
      
        public Form1(string nick, int number)
        {
            InitializeComponent();
            nickname = nick;
            index = number;
        }

        private void CheckForWinner()
        {
            foreach (Control control in table.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    if (iconLabel.ForeColor == iconLabel.BackColor)
                    {
                        return;
                    }
                }
            }
            timer2.Stop();
            using (StreamWriter file = File.AppendText("Record.txt"))
            {
                file.WriteLine($"{nickname}");
                file.WriteLine($"{record}");
                file.WriteLine($"{2 + (index * 2)}x{2 + (index * 2)}");
                file.WriteLine($"{count}");
            }
            this.Close();
            Close();
        }

        private void AssignIconsToSquares()
        {
            if (icons == null && index != 0)
            {
                Lcons();
            }
            foreach (Control control in table.Controls)
            {
                Label iconLabel = control as Label;
                if (iconLabel != null)
                {
                    int randomNumber = random.Next(icons.Count);
                    iconLabel.Text = icons[randomNumber];
                    iconLabel.ForeColor = iconLabel.BackColor;
                    icons.RemoveAt(randomNumber);
                }
            }
        }

        private void label_Click(object sender, EventArgs e)
        {
            count++;
            if (timer1.Enabled == true)
            {
                return;
            }
            Label clickedLabel = sender as Label;

            if (clickedLabel != null)
            {
                if (clickedLabel.ForeColor == Color.Black)
                {
                    return;
                }
                if (firstClicked == null)
                {
                    firstClicked = clickedLabel;
                    firstClicked.ForeColor = Color.Black;
                    return;
                }
                secondClicked = clickedLabel;
                secondClicked.ForeColor = Color.Black;
                CheckForWinner();
                if (firstClicked.Text == secondClicked.Text)
                {
                    firstClicked = null;
                    secondClicked = null;
                    return;
                }
                timer1.Start();
            }
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            timer1.Stop();
            firstClicked.ForeColor = firstClicked.BackColor;
            secondClicked.ForeColor = secondClicked.BackColor;
            firstClicked = null;
            secondClicked = null;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer2.Start();
            table = new TableLayoutPanel();
            if (this.Controls.Contains(table))
            {
                table = null;
            }
            table = new TableLayoutPanel();
            table.Dock = DockStyle.Fill;
            Width = Convert.ToInt32(this.Width);
            Height = Convert.ToInt32(this.Height);
            table.BackColor = Color.CornflowerBlue;
            table.CellBorderStyle = TableLayoutPanelCellBorderStyle.Inset;
            table.Location = new System.Drawing.Point(0, 0);
            this.Controls.Add(table);
            table.Visible = true;
            table.ColumnCount = 2 + (index * 2);
            table.RowCount = 2 + (index * 2);
            int width = 100 / table.ColumnCount;
            int height = 100 / table.RowCount;
            for (int col = 0; col < table.ColumnCount; col++)
            {
                table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, width));
                for (int row = 0; row < table.RowCount; row++)
                {
                    if (col == 0)
                    {
                        table.RowStyles.Add(new RowStyle(SizeType.Percent, height));
                    }
                    var label = new Label();
                    label.AutoSize = false;
                    label.Font = new Font("Webdings", size);
                    label.Name = ("label" + row + col).ToString();
                    label.Dock = DockStyle.Fill;
                    label.Text = 'с'.ToString();
                    label.TextAlign = ContentAlignment.MiddleCenter;
                    label.Click += label_Click;
                    table.Controls.Add(label, col, row);
                }
            }
            Controls.Add(table);
            AssignIconsToSquares();
        }
        private void timer2_Tick(object sender, EventArgs e)
        {
            record++;

        }
    }
}
