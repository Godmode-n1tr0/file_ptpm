﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pract_20_1
{
    public partial class Form1 : Form
    {
        int count = 0;
        int count2 = 0;
        public Form1()
        {
            InitializeComponent();
            groupBox1.Visible = false;
            groupBox2.Visible = false;
            groupBox3.Visible = false;
            groupBox4.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (comboBox1.SelectedIndex == 0)
            {
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
                label1.Visible = false;
                comboBox1.Visible = false;
                button1.Visible = false;
                groupBox1.Visible = true;

            }
            if (comboBox1.SelectedIndex == 1)
            {
                textBox6.Clear();
                textBox7.Clear();
                textBox8.Clear();
                textBox10.Clear();
                label1.Visible = false;
                comboBox1.Visible = false;
                button1.Visible = false;
                groupBox2.Visible = true;

            }
        }
        private void LoadSpectacles(bool isLocal)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Columns.Clear();

            if (isLocal)
            {
                dataGridView1.ColumnCount = 7;
                dataGridView1.Columns[0].HeaderText = "Тип";
                dataGridView1.Columns[1].HeaderText = "Название";
                dataGridView1.Columns[2].HeaderText = "Жанр";
                dataGridView1.Columns[3].HeaderText = "Автор";
                dataGridView1.Columns[4].HeaderText = "Режиссер";
                dataGridView1.Columns[5].HeaderText = "Театр";
                dataGridView1.Columns[6].HeaderText = "Кол-во показов";
            }
            else
            {
                dataGridView1.ColumnCount = 8;
                dataGridView1.Columns[0].HeaderText = "Тип";
                dataGridView1.Columns[1].HeaderText = "Название";
                dataGridView1.Columns[2].HeaderText = "Жанр";
                dataGridView1.Columns[3].HeaderText = "Автор";
                dataGridView1.Columns[4].HeaderText = "Режиссер";
                dataGridView1.Columns[5].HeaderText = "Дата начала";
                dataGridView1.Columns[6].HeaderText = "Дата конца";
                dataGridView1.Columns[7].HeaderText = "Площадка";
            }

            try
            {
                using (StreamReader file = new StreamReader("Spectacl.txt"))
                {
                    string line;
                    while ((line = file.ReadLine()) != null)
                    {
                        if ((line == "Местный спектакль" && isLocal) ||
                            (line == "Гастрольный спектакль" && !isLocal))
                        {
                            int fieldsCount = isLocal ? 7 : 8;
                            string[] rowData = new string[fieldsCount];
                            rowData[0] = line;

                            for (int i = 1; i < fieldsCount; i++)
                            {
                                rowData[i] = file.ReadLine();
                            }

                            dataGridView1.Rows.Add(rowData);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при чтении файла: {ex.Message}");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            count++;
            if (count > 0)
            {
                button2.Enabled = false;
                count = 0;
            }
            string title = textBox1.Text;
            string genre = comboBox2.Text;
            string author = textBox2.Text;
            string director = textBox3.Text;
            DateTime start;
            DateTime end;
            string format = "dd.MM.yyyy";
            while (true)
            {
                if (DateTime.TryParseExact(textBox4.Text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out start))
                {
                    start = start.Date;
                    break;
                }
                button3.Visible = true;
                MessageBox.Show("Некорректный формат даты. Используйте ДД.ММ.ГГГГ");
                return;
            }

            while (true)
            {
                if (DateTime.TryParseExact(textBox5.Text, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out end))
                {
                    end = end.Date;
                    break;
                }
                button3.Visible = true;
                MessageBox.Show("Некорректный формат даты. Используйте ДД.ММ.ГГГГ");
                return;
            }
            string venue = comboBox3.Text;
            var spectacle = new GSpectacl(title, genre, author, director, start, end, venue);
            MessageBox.Show("Спектакль создан!");   
            using (StreamWriter file = File.AppendText("Spectacl.txt"))
            {
                foreach (var spectakl in Spectacl.AllSpectacles)
                {
                    file.WriteLine(spectacle.Info());
                }
            }
            groupBox1.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }


        private void button3_Click(object sender, EventArgs e)
        {
            
            string title = textBox6.Text;
            string genre = comboBox5.Text;
            string author = textBox8.Text;
            string director = textBox10.Text;
            string theater = comboBox4.Text;
            int count = Convert.ToInt32(textBox7.Text);
            if (count > 300)
            {
                button3.Visible = true;
                MessageBox.Show($"Число показов в театре должно быть меньше 300.\n");
                return;
            }
            if (count < 1)
            {
                button3.Visible = true;
                MessageBox.Show($"Число показов в театре должно быть как минимум 1.\n");
                return;
            }
            count2++;
            if (count2 > 0)
            {
                button3.Enabled = false;
                count2 = 0;
            }
            var spectacle = new MSpectacl(title, genre, author, director, theater, count);
            MessageBox.Show("Спектакль создан!");
            using (StreamWriter file = File.AppendText("Spectacl.txt"))
            {
                foreach (var spectakl in Spectacl.AllSpectacles)
                {
                    file.WriteLine(spectacle.Info());
                    file.WriteLine("#");
                }
            }
            groupBox2.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            groupBox2.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            label1.Visible = true;
            comboBox1.Visible = true;
            button1.Visible = true;
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите строку для удаления");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int rowIndex = selectedRow.Index;
            if (MessageBox.Show("Удалить выбранный спектакль?", "Подтверждение",MessageBoxButtons.YesNo) == DialogResult.No)
                return;

            dataGridView1.Rows.Remove(selectedRow);

            RewriteFileCompletely(rowIndex);

            dataGridView1.Refresh();
        }
        private void RewriteFileCompletely(int deletedRowIndex)
        {
            try
            {
                bool isLocal = comboBox6.SelectedIndex == 1;
                string currentType = isLocal ? "Местный спектакль" : "Гастрольный спектакль";
                int fieldsCount = isLocal ? 7 : 8;

                List<string> fileLines = File.ReadAllLines("Spectacl.txt").ToList();
                List<string> newFileContent = new List<string>();

                int currentIndex = 0;
                for (int i = 0; i < fileLines.Count; i++)
                {
                    if (fileLines[i] == currentType)
                    {
                        if (currentIndex == deletedRowIndex)
                        {
                            i += fieldsCount - 1;
                        }
                        else
                        {
                            for (int j = 0; j < fieldsCount && i + j < fileLines.Count; j++)
                            {
                                newFileContent.Add(fileLines[i + j]);
                            }
                            i += fieldsCount - 1;
                        }
                        currentIndex++;
                    }
                    else
                    {
                        newFileContent.Add(fileLines[i]);
                    }
                }

                File.WriteAllLines("Spectacl.txt", newFileContent);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при удалении: {ex.Message}");
            }
        }
        private void Mestni()
        {
            LoadSpectacles(isLocal: true);
        }

        private void Gastroli()
        {
            LoadSpectacles(isLocal: false);
        }
        private void comboBox6_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox6.SelectedIndex == 0)
            {
                groupBox4.Visible = false;

                dataGridView1.Refresh();
                Gastroli();
                groupBox3.Visible = true;
            }
            if (comboBox6.SelectedIndex == 1)
            {
                groupBox3.Visible = false;
                dataGridView1.Refresh();
                Mestni();
                groupBox4.Visible = true;
            }
        }
            
        private void button9_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите спектакль для изменения");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int rowIndex = selectedRow.Index;

            string title = textBox20.Text;
            string genre = textBox19.Text;
            string author = textBox22.Text;
            string director = textBox24.Text;
            string theater = textBox23.Text;
            int count = Convert.ToInt32(textBox25.Text);

            selectedRow.Cells[1].Value = title;
            selectedRow.Cells[2].Value = genre;
            selectedRow.Cells[3].Value = author;
            selectedRow.Cells[4].Value = director;
            selectedRow.Cells[5].Value = theater;
            selectedRow.Cells[6].Value = count;

            UpdateSpectacleInFile(rowIndex, isLocal: true);
            MessageBox.Show("Изменения местного спектакля сохранены!");
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Выберите спектакль для изменения");
                return;
            }

            DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
            int rowIndex = selectedRow.Index;


            string title = textBox12.Text;
            string genre = textBox13.Text;
            string author = textBox14.Text;
            string director = textBox15.Text;
            string startDate = textBox17.Text;
            string endDate = textBox16.Text;
            string venue = textBox18.Text;

            selectedRow.Cells[1].Value = title;
            selectedRow.Cells[2].Value = genre;
            selectedRow.Cells[3].Value = author;
            selectedRow.Cells[4].Value = director;
            selectedRow.Cells[5].Value = startDate;
            selectedRow.Cells[6].Value = endDate;
            selectedRow.Cells[7].Value = venue;


            UpdateSpectacleInFile(rowIndex, isLocal: false);
            MessageBox.Show("Изменения гастрольного спектакля сохранены!");
        }
        private void UpdateSpectacleInFile(int updatedRowIndex, bool isLocal)
        {
            try
            {
                string currentType = isLocal ? "Местный спектакль" : "Гастрольный спектакль";
                int fieldsCount = isLocal ? 7 : 8;

                List<string> fileLines = File.ReadAllLines("Spectacl.txt").ToList();
                List<string> newFileContent = new List<string>();

                int currentIndex = 0;
                for (int i = 0; i < fileLines.Count; i++)
                {
                    if (fileLines[i] == currentType)
                    {
                        if (currentIndex == updatedRowIndex)
                        {
                            DataGridViewRow row = dataGridView1.Rows[updatedRowIndex];

                            newFileContent.Add(currentType);

                            for (int j = 1; j < row.Cells.Count; j++)
                            {
                                newFileContent.Add(row.Cells[j].Value?.ToString() ?? "");
                            }

                            i += fieldsCount - 1;
                        }
                        else
                        {
                            for (int j = 0; j < fieldsCount && i + j < fileLines.Count; j++)
                            {
                                newFileContent.Add(fileLines[i + j]);
                            }
                            i += fieldsCount - 1;
                        }
                        currentIndex++;
                    }
                    else
                    {
                        newFileContent.Add(fileLines[i]);
                    }
                }

                File.WriteAllLines("Spectacl.txt", newFileContent);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка при обновлении файла: {ex.Message}");
            }
        }

        private void dataGridView1_SelectionChanged(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count > 0)
            {
                DataGridViewRow row = dataGridView1.SelectedRows[0];
                bool isLocal = row.Cells[0].Value.ToString() == "Местный спектакль";

                if (isLocal && groupBox4.Visible)
                {
                    textBox20.Text = row.Cells[1].Value?.ToString() ?? "";
                    textBox19.Text = row.Cells[2].Value?.ToString() ?? "";
                    textBox22.Text = row.Cells[3].Value?.ToString() ?? "";
                    textBox24.Text = row.Cells[4].Value?.ToString() ?? "";
                    textBox23.Text = row.Cells[5].Value?.ToString() ?? "";
                    textBox25.Text = row.Cells[6].Value?.ToString() ?? "";
                }
                else if (!isLocal && groupBox3.Visible)
                {
                    textBox12.Text = row.Cells[1].Value?.ToString() ?? "";
                    textBox13.Text = row.Cells[2].Value?.ToString() ?? "";
                    textBox14.Text = row.Cells[3].Value?.ToString() ?? "";
                    textBox15.Text = row.Cells[4].Value?.ToString() ?? "";
                    textBox17.Text = row.Cells[5].Value?.ToString() ?? "";
                    textBox16.Text = row.Cells[6].Value?.ToString() ?? "";
                    textBox18.Text = row.Cells[7].Value?.ToString() ?? "";
                }
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            string criterial1 = textBox9.Text.ToLower();
            string criterial2 = textBox11.Text.ToLower();
            bool isLocal = comboBox6.SelectedIndex == 1;
            dataGridView1.ClearSelection();
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    bool match = false;

                    if ((isLocal && row.Cells[0].Value.ToString() == "Местный спектакль") || (!isLocal && row.Cells[0].Value.ToString() == "Гастрольный спектакль"))
                    {
                        if (string.IsNullOrEmpty(criterial1) && string.IsNullOrEmpty(criterial2))
                        {
                            match = true;
                        }
                        else
                        {
                            bool matchesCriterial1 = string.IsNullOrEmpty(criterial1) ||
                            row.Cells.Cast<DataGridViewCell>().Any(cell => cell.Value != null && cell.Value.ToString().ToLower().Contains(criterial1));

                            bool matchesCriterial2 = string.IsNullOrEmpty(criterial1) ||
                                row.Cells.Cast<DataGridViewCell>().Any(cell => cell.Value != null && cell.Value.ToString().ToLower().Contains(criterial2));

                            if (!string.IsNullOrEmpty(criterial1) && !string.IsNullOrEmpty(criterial2))
                            {
                                match = matchesCriterial1 && matchesCriterial2;
                            }
                            else
                            {
                                match = matchesCriterial1 || matchesCriterial2;
                            }
                        }
                    }
                    row.Visible = match;
                    if (match)
                    {
                        row.Selected = true;
                    }
                }
            }
            if (dataGridView1.SelectedRows.Count == 0)
            {
                MessageBox.Show("Спектакли по заданным критериям не найдены");
            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            textBox9.Text = "";
            textBox10.Text = "";
            foreach (DataGridViewRow row in dataGridView1.Rows)
            {
                if (!row.IsNewRow)
                {
                    row.Visible = true;
                }
            }
            dataGridView1.ClearSelection();
        }
    }
}
