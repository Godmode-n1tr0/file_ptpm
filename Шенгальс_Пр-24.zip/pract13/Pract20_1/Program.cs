﻿using System;
using Pract20_1;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Pract20_1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Театральная система - ввод данных\n");

            try
            {
                var local = new LocalPerformance(
                    title: "Горе от ума",
                    genre: "Комедия",
                    author: "А.С. Грибоедов",
                    director: "Иванов И.И.",
                    theaterName: "Московский художественный театр",
                    productionsPerSeason: 15);

                var touring = new TouringPerformance(
                    title: "Лебединое озеро",
                    genre: "Балет",
                    author: "П.И. Чайковский",
                    director: "Петров П.П.",
                    tourStart: new DateTime(2023, 6, 1),
                    tourEnd: new DateTime(2023, 6, 30),
                    venue: "Большой театр");

                Console.WriteLine("Добавлены спектакли:\n");

                foreach (var performance in Spectacl.Performances)
                {
                    Console.WriteLine(performance.Info());
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }

            Console.WriteLine("\nНажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
    }
    }
}
