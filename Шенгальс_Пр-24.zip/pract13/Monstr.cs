﻿namespace pract13
{
    public class Monstr
    {
        Random r = new Random();
        public string name;
        private int hp;
        private int damage;
        public string imagename;
        static string[] haract = new string[8] { "Добрый", "Эгоист", "Злой", "Неуровновешанный", "Славный", "Мужественный", "Разьяренный", "Бешенный" };
        static string[] names = new string[8] { "Исаги", "Рео", "Сидо", "Эго", "Наги", "Бачира", "Сае", "Кайзер" };

        public Monstr()
        {
            Create_name();
            Sethp();
            Getdamage();
            name = names[r.Next(8)] + " " + haract[r.Next(8)];
            damage = r.Next(15, 20);
        }
        public string Create_name()
        {
            return name;
        }
        public int GetHp()
        {
            return hp;
        }
        public void Sethp()
        {
            hp = r.Next(75, 100);
        }
        public int Getdamage()
        {
            return damage;
        }
        public void TakeDamage(int dmg, bool isDoubleDamage)
        {
            if (isDoubleDamage)
            {
                hp -= dmg * 2;
                Console.WriteLine($"{name} получает двойной урон: {dmg * 2}!");
                if (hp < 0)
                {
                    hp = 0;
                }
            }
            else
            {
                hp -= dmg;
                Console.WriteLine($"{name} получает урон: {dmg}!");
                if (hp < 0)
                {
                    hp = 0;
                }
            }
        }

        public void drawmonster()
        {
            Console.WriteLine($"+------{name}\n| Здоровье: {hp}\n| Урон: {damage}\n+-----------");
        }
    }
}
