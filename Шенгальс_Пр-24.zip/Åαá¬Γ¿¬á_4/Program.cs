﻿using System.Text.RegularExpressions;

static int ReadFile(List<int> arr, string name, int count)
{
    StreamReader sr = File.OpenText(name);
    int number = Convert.ToInt32(sr.ReadLine());
    while (!sr.EndOfStream)
    {
        arr.Add(Convert.ToInt32(sr.ReadLine()));
        int num = Convert.ToInt32(sr.ReadLine());
        if (number == num)
        {
            count++;
        }
    }
    sr.Close();
    return count;
}
int count = 0;
List<int> arr1 = new List<int>();
List<int> arr2 = new List<int>();
count = ReadFile(arr1, "arr1.txt", count);
StreamWriter sw = File.CreateText("Result.txt");
sw.WriteLine($"Количество элементов равных первому в S: {count+1}");
count = 0;
count =ReadFile(arr2, "arr2.txt", count);
sw.WriteLine($"Количество элементов равных первому в T: {count+1}");
sw.Close();
Console.WriteLine("Ответ получен");