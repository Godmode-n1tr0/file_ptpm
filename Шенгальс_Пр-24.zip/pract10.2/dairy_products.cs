﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract10._2
{
    internal class Dairy_products
    {
        private string _name;
        private double _weight;
        private double _fatContent;

        public string Manufacturer { get; set; }
        public decimal Price { get; set; }

        public string GetName() => _name;
        public void SetName(string value) => _name = value;

        public double GetWeight() => _weight;
        public void SetWeight(double value) => _weight = value;

        public double GetFatContent() => _fatContent;
        public void SetFatContent(double value) => _fatContent = value;

        public Dairy_products() { }

        public Dairy_products(string name, double weight, double fatContent)
        {
            _name = name;
            _weight = weight;
            _fatContent = fatContent;
        }
    }
}
