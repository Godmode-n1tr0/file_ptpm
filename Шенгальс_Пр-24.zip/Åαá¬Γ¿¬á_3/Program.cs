﻿Console.Write("Введите номер задания: ");
int a1 = Convert.ToInt32(Console.ReadLine());
static string RemoveExtraSpaces(string input)
{
    input = input.Trim();

    while (input.Contains("  "))
    {
        input = input.Replace("  ", " ");
    }

    return input;
}
static string Encrypt(string input, int key)
{
    string result = "";

    foreach (char c in input)
    {
        if (char.IsLetter(c))
        {
            char shiftedChar = ShiftCharacter(c, key);
            result += shiftedChar;
        }
        else
        {
            result += c;
        }
    }

    return result;
}
static char ShiftCharacter(char c, int key)
{
    int baseCode = char.IsUpper(c) ? 'А' : 'а';
    int position = c - baseCode;
    int shiftedPosition = (position + key) % 32;
    return (char)(baseCode + shiftedPosition);
}
if (a1 == 1)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    string result = RemoveExtraSpaces(text);
    Console.WriteLine(result);
}
else if (a1 == 2)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string input = Console.ReadLine();
    Console.Write("Введите ключ от 1-9: ");
    int key = Convert.ToInt32(Console.ReadLine());

    string encryptedText = Encrypt(input, key);
    Console.WriteLine($"Зашифрованная строка: {encryptedText}");
}
