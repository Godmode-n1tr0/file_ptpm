﻿using System;
using System.Globalization;
using System.Runtime.CompilerServices;

static string Reverse(string str)
{
    string text2 = "";
    for (int i = str.Length - 1; i >= 0; i--)
    {
        text2 += str[i];
    }
    return text2;
}
Console.Write("Введите номер задания: ");
int a1 = Convert.ToInt32(Console.ReadLine());
if (a1 == 1)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    text = text.Replace("оо", "*");
    Console.WriteLine(text);
}
else if (a1 == 2)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    text = text.Replace(",", "  ");
    Console.WriteLine(text);
}
else if (a1 == 3)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    for (int i = 0; i < text.Length; i++)
    {
        text = text.Remove(i, 1);
    }
    Console.WriteLine(text);
}
else if (a1 == 4)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    for (int i = 0; i < text.Length; i++)
    {
        if (i % 6 == 0)
        {
            text = text.Insert(i, "+");
        }
    }
    Console.WriteLine(text);
}
else if (a1 == 5)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    int count1 = 0;
    int count2 = 0;
    for (int i = 0; i < text.Length; i++)
    {
        if (text[i] == 'а')
        {
            count1++;
        }
        else if (text[i] == 'в')
        {
            count2++;
        }
    }
    Console.WriteLine($"Кол-во 'a': {count1}\nКол-во 'в': {count2}");
}
else if (a1 == 6)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    for (int i = 0; i < text.Length; i++)
    {
        text = text.Remove(i, 1);
    }
    Console.WriteLine(text);
}
else if (a1 == 7)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    int a = text.IndexOf(" ");
    int b = text.LastIndexOf(" ");
    string c = text.Substring(b - a, a);
    text = text.Remove(a, b - a);
    string v = text + " " + c;
    Console.WriteLine(v);
}
else if (a1 == 8)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    string[] words = text.Split(' ');
    for (int i = 0; i < words.Length; i++)
    {
        if (words[i] == "DOG")
        {
            words[i] = "CAT";
        }
        else if (words[i] == "CAT")
        {
            words[i] = "DOG";
        }
    }
    text = string.Join(" ", words);
    Console.WriteLine(text);
}
else if (a1 == 9)
{
    Console.Clear();
    Console.WriteLine("Дан текст: Синий Красный Черный");
    string text = "Синий Красный Черный";
    string a = "";
    string b = "";
    string c = "";
    string[] words = text.Split(' ');
    for (int i = 0; i < words.Length; i++)
    {
        if (words[i] == "Синий")
        {
            a = "Синий";
        }
        else if (words[i] == "Красный")
        {
            b = "Красный";
        }
        else if (words[i] == "Черный")
        {
            c = "Черный";
        }
    }
    Console.WriteLine($"{text}\n{a}\n{b}\n{c}");
}
else if (a1 == 10)
{
    Console.Clear();
    string[] words = new string[3];
    Console.Write("Введите фамилию: ");
    words[0] = Console.ReadLine();
    Console.Write("Введите имя: ");
    words[1] = Console.ReadLine();
    Console.Write("Введите отчество: ");
    words[2] = Console.ReadLine();
    string c = string.Join(" ", words);
    Console.WriteLine($"Добро пожаловать, {c}!");
}
else if (a1 == 11)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Convert.ToString(Console.ReadLine());
    for (int i = 0; i < text.Length; i++)
    {
        if (char.IsNumber(text[i]) == true)
        {
            text = text.Remove(i, 1);
            i--;
        }
    }
    Console.WriteLine(text);
}
else if (a1 == 12)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    int count = 0;
    string text = Convert.ToString(Console.ReadLine());
    for (int i = 0; i < text.Length; i++)
    {
        count = text.Length;
        Console.WriteLine(text[i]);
    }
    Console.WriteLine();
    Console.WriteLine(count);
}
else if (a1 == 13)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    int count = 1;
    string text = Convert.ToString(Console.ReadLine());
    string[] worlds = text.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
    for (int i = 0; i < text.Length; i++)
    {
        if (text[i] == ' ' && char.IsLetter(text[i - 1]))
        {
            count++;
        }
    }
    Console.WriteLine($"Кол-во строк с помощью сплита: {worlds.Length}");
    Console.WriteLine($"Кол-во строк с помощью позиций пробела: {count}");
}
else if (a1 == 14)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    string revers = Reverse(text);
    Console.WriteLine(revers);
}
else if (a1 == 15)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    string slovo = text;
    string revers = Reverse(text);
    bool b = revers.Contains(slovo);
    if (b == true)
    {
        Console.WriteLine($"Слово: {revers} палидром");
    }
    else
    {
        Console.WriteLine($"Слово: {revers} не палидром");
    }
}
else if (a1 == 16)
{
    Console.Clear();
    string[] worlds = new string[3];
    Console.Write("Введите фамилию: ");
    worlds[0] = Console.ReadLine();

    Console.Write("Введите имя: ");
    worlds[1] = Console.ReadLine();

    Console.Write("Введите Отчество: ");
    worlds[2] = Console.ReadLine();

    string c = string.Join(" ", worlds);
    Console.Clear();
    Console.WriteLine($"ФИО - {c}");
    string s = c.ToLower();
    Console.WriteLine();
    Console.WriteLine($"ФИО - {s}");
}
else if (a1 == 17)
{
    Console.Clear();
    string text = "Hello, world";
    text = text.Remove(0, 7);
    Console.WriteLine(text);
}
else if (a1 == 18)
{
    Console.Clear();
    string text = "Hello, world";
    string text1 = "beautiful";
    text = text.Insert(7, text1 + " ");
    Console.WriteLine(text);
}
else if (a1 == 19)
{
    Console.Clear();
    int count = 0;
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    for (int i = 0; i < text.Length; i++)
    {
        if (char.IsSeparator(text[i]) == true)
        {
            count = i;
            Console.WriteLine(count + 1);
        }
    }
}
else if (a1 == 20)
{
    Console.Clear();
    int count = 0;
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    for (int i = 0; i < text.Length; i++)
    {
        if (char.IsSeparator(text[i]) == true)
        {
            count = i + 1;
            text = text.Remove(0, count);
            Console.WriteLine(text);
        }
    }
}
else if (a1 == 21)
{
    Console.Clear();
    int count = 0;
    string c = "";
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    for (int i = 0; i < text.Length; i++)
    {
        if (char.IsSeparator(text[i]) == true)
        {
            int a = text.IndexOf(" ");
            int b = text.LastIndexOf(" ");
            c = text.Substring(b - a, b);
            text = text.Remove(0, b);
            count = i + 1;
        }
    }
    Console.WriteLine($"Имя - {c}\nФамилия - {text}");
    Console.WriteLine();
    Console.WriteLine($"Пробел находится на {count} символе");
}
else if (a1 == 22)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    int a = text.IndexOf(" ");
    int b = text.LastIndexOf(" ");
    string name = text.Remove(a - text.LastIndexOf(text));
    string familiay = text.Substring(a + 1, b - a - 1);
    string otchestrvo = text.Remove(0, b);
    Console.WriteLine($"Имя - {name}\nФамилия - {familiay}\nОтчество - {otchestrvo}");
}
else if (a1 == 23)
{
    Console.Clear();
    Console.WriteLine("Введите путь файла: ");
    string file = Console.ReadLine();
    Console.Clear();
    int lastIndex = file.LastIndexOf('\\');
    if (lastIndex == -1)
    {
        lastIndex = file.LastIndexOf('/');
    }
    string directoryPath = lastIndex == -1 ? "" : file.Substring(0, lastIndex);
    Console.WriteLine($"Путь без имени файла: '{directoryPath}'");

    string fileName = lastIndex == -1 ? file : file.Substring(lastIndex + 1);
    Console.WriteLine($"Имя файла с расширением: '{fileName}'");

    int lastDotIndex = fileName.LastIndexOf('.');
    string fileExtension = lastDotIndex == -1 ? "" : fileName.Substring(lastDotIndex);
    Console.WriteLine($"Расширение имени файла: '{fileExtension}'");

    string fileNameWithoutExtension = (lastDotIndex == -1) ? fileName : fileName.Substring(0, lastDotIndex);
    Console.WriteLine($"Имя файла без пути и без расширения: '{fileNameWithoutExtension}'");

}
else if (a1 == 24)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    for (int i = 0; i < text.Length; i++)
    {
        if (char.IsPunctuation(text[i]) == true)
        {
            Console.WriteLine(text[i]);
        }
    }
}
else if (a1 == 25)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();

    char[] worlds = new char[] { '.', '!', '?' };

    string[] sentex = text.Split(worlds, StringSplitOptions.RemoveEmptyEntries);

    int sentexC = sentex.Length;

    Console.WriteLine($"Количество предложений: {sentexC}");
}
else if (a1 == 26)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    string text = Console.ReadLine();
    char[] worlds = new char[] { ' ', ',', '.', '!', '?', ';', ':' };

    string[] words = text.Split(worlds, StringSplitOptions.RemoveEmptyEntries);

    int wordCount = words.Length;

    Console.WriteLine($"Количество слов: {wordCount}");
}
else if (a1 == 27)
{
    Console.Clear();
    Console.Write("Введите текст: ");
    int countIF = 0;
    int countIS = 0;
    string text = Console.ReadLine();
    for (int i = 0; i < text.Length; i++)
    {
        if (text[i] == ' ')
        {
            countIF++;
        }
        if (char.IsSeparator(text[i]) == true)
        {
            countIS++;
        }
    }
    Console.WriteLine($"\nПробелов с помощью 'if': {countIF}\nПробелов с помощью 'is': {countIS}");
}
else if (a1 == 28)
{
    Console.Clear();
    string text = Console.ReadLine();


    if (string.IsNullOrEmpty(text))
    {
        Console.WriteLine("Пятые слова: не найдены");
        return;
    }

    int wordCount = 0;
    int startIndex = -1;
    int endIndex = -1;
    char[] chars = text.ToCharArray();
    bool found = false;

    for (int i = 0; i < chars.Length; i++)
    {
        if (chars[i] != ' ')
        {
            if (startIndex == -1)
            {
                startIndex = i;
                wordCount++;
            }
        }
        else if (startIndex != -1)
        {
            endIndex = i;

            if (wordCount % 5 == 0)
            {
                Console.Write("Пятое слово: ");
                for (int j = startIndex; j < endIndex; j++)
                {
                    Console.Write(chars[j]);
                }
                Console.WriteLine();
                found = true;
            }

            startIndex = -1;
        }
    }

    if (wordCount % 5 == 0 && startIndex != -1)
    {
        Console.Write("Пятое слово: ");
        for (int j = startIndex; j < chars.Length; j++)
        {
            Console.Write(chars[j]);
        }
        Console.WriteLine();
        found = true;
    }

    if (!found)
    {
        Console.WriteLine("Пятые слова: не найдены");
    }
}