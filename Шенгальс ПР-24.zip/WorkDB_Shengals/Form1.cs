﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Runtime.Remoting.Contexts;
using System.Runtime.Remoting.Messaging;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Tab;

namespace WorkDB_Shengals
{
    public partial class Authorization_frm : Form
    {
        int count = 0;
        SqlDataAdapter adptr;
        DataTable table;
        public void UpdateData()
        {
            Validation.UpdateData(dataGridView2);
        }
        public void CheckActive(string log)
        {
            string findconnetion = $"Select * from User_tbl where Login = '{log}'";
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();
                SqlCommand command = new SqlCommand(findconnetion, connection);
                SqlDataReader reader = command.ExecuteReader();

                reader.Read();
                if (reader.HasRows)
                {
                    if (reader["Login"].ToString() == log)
                    {
                        reader.Close();
                        int id = Convert.ToInt32(command.ExecuteScalar());
                        string updateQuery = $"UPDATE User_tbl SET Active = 'False' where ID = '{id}'";
                        SqlCommand Ucommand = new SqlCommand(updateQuery, connection);
                        command.Parameters.AddWithValue("False", id);
                        int check = Ucommand.ExecuteNonQuery();
                        if (check > 0)
                        {
                            MessageBox.Show("Вы заблокированы. Обратитесь к администратору системы");
                            Input_btn.Enabled = false;
                            UpdateData();
                        }
                    }
                }

            }
        }
        public void CheckRights(string log, string pass)
        {
            DateTime today = DateTime.Now;
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";

            using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();

                string findConnection = $"SELECT * FROM User_tbl WHERE Login = '{log}' AND Password = '{pass}' AND Active = 'True'";
                SqlCommand command = new SqlCommand(findConnection, connection);

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    if (reader.HasRows)
                    {
                        reader.Read();

                        string dbLogin = reader["Login"].ToString();
                        string dbPassword = reader["Password"].ToString();
                        string dbActive = reader["Active"].ToString();
                        DateTime lastLoginDate = Convert.ToDateTime(reader["Date"]);
                        string role = reader["Role"].ToString();

                        reader.Close();

                        UpdateLastLoginDate(connection, log);

                        if (dbLogin == log && dbPassword == pass && dbActive == "True")
                        {
                            TimeSpan difference = today - lastLoginDate;

                            if (role == "Admin")
                            {
                                this.Hide();
                                Admin_frm admin = new Admin_frm();
                                admin.Show();
                            }
                            else if (role == "User")
                            {
                                if (difference.TotalDays <= 14)
                                {
                                    this.Hide();
                                    Root_frm root = new Root_frm();
                                    root.Show();
                                }
                                else
                                {
                                    this.Hide();
                                    UpdatePass upass = new UpdatePass();
                                    upass.Show();
                                }
                            }
                            return;
                        }
                    }
                }

                MessageBox.Show("Вы ввели неправильно логин или пароль, либо ваша учетная запись заблокирована.");
            }
        }
        private void UpdateLastLoginDate(SqlConnection connection, string login)
        {
            string updateQuery = "UPDATE User_tbl SET Date = GETDATE() WHERE Login = @Login";

            using (SqlCommand command = new SqlCommand(updateQuery, connection))
            {
                command.Parameters.AddWithValue("@Login", login);
                command.ExecuteNonQuery();
            }
        }
        public void AddRow(string log)
        {
            string connect = @"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;";
            string findconnetion = $"Select * from User_tbl where Login = '{log}'";
            string query = $"Insert into dbo.User_tbl (Login, Password, Count, Date, Active, Role)\r\nvalues ('{Vallog_Txt.Text}', '{Valpassword_Txt.Text}', '0', '2025-05-1', 'True', 'user')";
            using (SqlConnection connection = new SqlConnection(connect))
            {
                connection.Open();
                SqlCommand datereader = new SqlCommand(findconnetion, connection);
                SqlDataReader reader = datereader.ExecuteReader();
                reader.Read();
                if (reader.HasRows)
                {
                    if (reader["Login"].ToString() == log)
                    {
                        MessageBox.Show("Такое имя уже есть введите другое");
                    }

                }
                else
                {
                    using (SqlConnection connecta = new SqlConnection(connect))
                    {
                        connecta.Open();
                        SqlCommand command = new SqlCommand(query, connecta);
                        int number = command.ExecuteNonQuery();
                        MessageBox.Show($"Добавлено объектов: {number}");
                    }
                }
            }
        }
        public Authorization_frm()
        {
            InitializeComponent();
            UpdateData();
        }

        private void Input_btn_Click(object sender, EventArgs e)
        {
            count++;
            string log = Log_Txt.Text;
            string pass = Pass_Txt.Text;
            if (count == 4)
            {
                CheckActive(log);
                return;
            }
            Validation.ValLog1(log, pass);
            string d = Validation.ValLog1(log, pass);
            if (d == "0")
            {
                CheckRights(log, pass);
                UpdateData();
            }
            else
            {
                switch (d)
                {
                    case "1":
                        MessageBox.Show("Ошибка, логин не может быть пустым");
                        break;
                    case "2":
                        MessageBox.Show("Ошибка, пароль не может быть пустым");
                        break;
                }
            }
        }

        private void Valinput_btn_Click(object sender, EventArgs e)
        {
            string log = Vallog_Txt.Text;
            string pass = Valpass_Txt.Text;
            string valpass = Valpassword_Txt.Text;
            Validation.ValLog(log, pass, valpass);
            string d = Validation.ValLog(log, pass, valpass);
            if (d == "0")
            {
                AddRow(log);
                UpdateData();
            }
            else
            {
                switch (d)
                {
                    case "1":
                        MessageBox.Show("Ошибка, логин не может быть пустым");
                        break;
                    case "2":
                        MessageBox.Show("Ошибка, пароль не может быть пустым");
                        break;
                    case "3":
                        MessageBox.Show("Ошибка пароли не совпадают");
                        break;
                }
            }
        }
    }
}
