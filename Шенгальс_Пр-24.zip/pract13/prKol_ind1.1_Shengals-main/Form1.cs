﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace prKol_ind1._1_Shengals
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        private void btnLoadFile_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*";
                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    try
                    {
                        string filePath = openFileDialog.FileName;

                        if (!File.Exists(filePath))
                        {
                            MessageBox.Show("Файл не найден", "Ошибка",
                                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        string fileContent = File.ReadAllText(filePath).Trim();
                        if (string.IsNullOrWhiteSpace(fileContent))
                        {
                            MessageBox.Show("Файл пуст", "Ошибка",
                                         MessageBoxButtons.OK, MessageBoxIcon.Error);
                            return;
                        }

                        string formula = new string(fileContent.Where(c => !char.IsWhiteSpace(c)).ToArray());
                        txtFormula.Text = formula;

                        double result = EvaluateFormula(formula);
                        txtResult.Text = result.ToString();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Ошибка: {ex.Message}", "Ошибка",
                                      MessageBoxButtons.OK, MessageBoxIcon.Error);
                        txtFormula.Text = "";
                        txtResult.Text = "";
                    }
                }
            }
        }

        private double EvaluateFormula(string formula)
        {
            if (string.IsNullOrEmpty(formula))
                throw new ArgumentException("Пустая формула");

            var tokens = new Stack<string>();
            string currentToken = "";

            foreach (char c in formula)
            {
                if (c == '(' || c == ',' || c == ')')
                {
                    if (!string.IsNullOrEmpty(currentToken))
                    {
                        tokens.Push(currentToken);
                        currentToken = "";
                    }
                    tokens.Push(c.ToString());
                }
                else
                {
                    currentToken += c;
                }
            }

            if (!string.IsNullOrEmpty(currentToken))
                tokens.Push(currentToken);

            var reversedTokens = new Stack<string>(tokens.Reverse());
            return EvaluateExpression(reversedTokens);
        }

        private double EvaluateExpression(Stack<string> tokens)
        {
            if (tokens.Count == 0)
                throw new ArgumentException("Неполная формула");

            string token = tokens.Pop();

            if (double.TryParse(token, out double number))
                return number;

            if (token == "M" || token == "m")
            {
                if (tokens.Count == 0 || tokens.Pop() != "(")
                    throw new ArgumentException("Отсутствует открывающая скобка");

                double left = EvaluateExpression(tokens);

                if (tokens.Count == 0 || tokens.Pop() != ",")
                    throw new ArgumentException("Отсутствует разделитель аргументов");

                double right = EvaluateExpression(tokens);

                if (tokens.Count == 0 || tokens.Pop() != ")")
                    throw new ArgumentException("Отсутствует закрывающая скобка");

                return token == "M" ? Math.Max(left, right) : Math.Min(left, right);
            }

            throw new ArgumentException($"Неизвестный оператор: {token}");
        }
    }
}
