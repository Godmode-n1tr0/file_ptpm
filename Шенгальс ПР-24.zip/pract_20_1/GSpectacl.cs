﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract_20_1
{
    public class GSpectacl : Spectacl
    {
        public DateTime TourStart { get; }
        public DateTime TourEnd { get; }
        public string Venue { get; }

        public GSpectacl(string title, string genre, string author, string director,
                        DateTime tourStart, DateTime tourEnd, string venue, bool checkDates = false)
            : base(title, genre, author, director)
        {
            string errors = Validation.ValidateDates(tourStart, tourEnd, "Дата начала", "Дата окончания", checkDates) +
                            Validation.ValidateString(venue, "Площадка");

            if (!string.IsNullOrEmpty(errors))
            {
                throw new ArgumentException(errors);
            }

            TourStart = tourStart;
            TourEnd = tourEnd;
            Venue = venue;
        }
    }
}
