﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pract_5
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }



        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox1.Text);
                double b = Convert.ToDouble(textBox2.Text);
                textBox3.Text = Convert.ToString(a + b);
            }
            catch
            {
                MessageBox.Show("Невернный ввод");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox1.Text);
                double b = Convert.ToDouble(textBox2.Text);
                textBox3.Text = Convert.ToString(a - b);
            }
            catch
            {
                MessageBox.Show("Невернный ввод");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox1.Text);
                double b = Convert.ToDouble(textBox2.Text);
                textBox3.Text = Convert.ToString(Math.Round((a / b), 2));
            }
            catch
            {
                MessageBox.Show("Невернный ввод");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox1.Text);
                double b = Convert.ToDouble(textBox2.Text);
                textBox3.Text = Convert.ToString(a * b);
            }
            catch
            {
                MessageBox.Show("Невернный ввод");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox1.Text);
                double b = Convert.ToDouble(textBox2.Text);
                textBox3.Text = Convert.ToString(Math.Pow(a, b));
            }
            catch
            {
                MessageBox.Show("Невернный ввод");
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox5.Text);
                double b = Convert.ToDouble(textBox4.Text);
                textBox6.Text = Convert.ToString((b-a)*365);
            }
            catch
            {
                MessageBox.Show("Невернный ввод");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            try
            {
                double a = Convert.ToDouble(textBox7.Text);
                double b = Convert.ToDouble(textBox8.Text);
                double c = Convert.ToDouble(textBox9.Text);
                textBox10.Text = Convert.ToString(a - c);
                textBox11.Text = Convert.ToString(b - c);
                textBox12.Text = Convert.ToString((a - c) + (b - c));
            }
            catch
            {
                MessageBox.Show("Невернный ввод");
            }
        }
    }
}
