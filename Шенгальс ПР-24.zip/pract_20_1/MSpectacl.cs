﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract_20_1
{
    public class MSpectacl : Spectacl
    {
        public string TheaterName { get; }
        public int PerformancesPerSeason { get; }

        public MSpectacl(string title, string genre, string author, string director,
                        string theaterName, int performancesPerSeason)
            : base(title, genre, author, director)
        {
            string errors = Validation.ValidateString(theaterName, "Театр") +
                            Validation.ValidatePositiveNumber(performancesPerSeason, "Количество показов");

            if (!string.IsNullOrEmpty(errors))
            {
                throw new ArgumentException(errors);
            }

            TheaterName = theaterName;
            PerformancesPerSeason = performancesPerSeason;
        }
    }
}
