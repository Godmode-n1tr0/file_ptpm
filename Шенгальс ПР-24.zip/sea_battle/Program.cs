﻿using System;

class Program
{
    private const int Size = 10;
    private static char[,] board = new char[Size, Size];
    private static int[] ships = { 4, 3, 3, 2, 2, 2, 1, 1, 1, 1 };
    private static int currentShip = 0;

    private static void Main()
    {
        Console.WriteLine("МОРСКОЙ БОЙ - РАССТАНОВКА КОРАБЛЕЙ");
        InitBoard();

        while (currentShip < ships.Length)
        {
            PrintBoard();
            if (ships[currentShip] == 1)
                PlaceSingleShip();
            else
                PlaceMultiShip(ships[currentShip]);
        }

        PrintBoard();
        Console.WriteLine("\nВсе корабли размещены! Игра готова.");
    }

    private static void InitBoard()
    {
        for (int i = 0; i < Size; i++)
            for (int j = 0; j < Size; j++)
                board[i, j] = '~';
    }

    private static void PrintBoard()
    {
        Console.WriteLine("\n  | 1 2 3 4 5 6 7 8 9 10");
        Console.WriteLine("--+---------------------");

        for (int i = 0; i < Size; i++)
        {
            Console.Write((i + 1).ToString().PadLeft(2) + "| ");
            for (int j = 0; j < Size; j++)
                Console.Write(board[i, j] + " ");
            Console.WriteLine();
        }
    }

    private static void PlaceSingleShip()
    {
        Console.WriteLine($"\nРазмещаем однопалубный корабль (осталось {ships.Length - currentShip})");

        int x = ReadCoordinate("X");
        int y = ReadCoordinate("Y");

        if (IsValidPlacement(x - 1, y - 1))
        {
            board[y - 1, x - 1] = 'O';
            currentShip++;
        }
        else
            Console.WriteLine("Нельзя разместить здесь! Попробуйте снова.");
    }

    private static void PlaceMultiShip(int size)
    {
        Console.WriteLine($"\nРазмещаем {size}-палубный корабль (осталось {ships.Length - currentShip})");

        int x1 = ReadCoordinate("X1");
        int y1 = ReadCoordinate("Y1");
        int x2 = ReadCoordinate("X2");
        int y2 = ReadCoordinate("Y2");

        if (!CheckAlignment(x1, y1, x2, y2, size))
        {
            Console.WriteLine("Корабль должен быть прямой линии нужной длины!");
            return;
        }

        if (PlaceShip(x1 - 1, y1 - 1, x2 - 1, y2 - 1, size))
            currentShip++;
        else
            Console.WriteLine("Нельзя разместить здесь! Попробуйте снова.");
    }

    private static bool CheckAlignment(int x1, int y1, int x2, int y2, int size)
    {
        return (x1 == x2 && Math.Abs(y1 - y2) == size - 1) ||
               (y1 == y2 && Math.Abs(x1 - x2) == size - 1);
    }

    private static bool PlaceShip(int x1, int y1, int x2, int y2, int size)
    {
        int startX = Math.Min(x1, x2);
        int startY = Math.Min(y1, y2);

        for (int i = 0; i < size; i++)
        {
            int x = (x1 == x2) ? x1 : startX + i;
            int y = (y1 == y2) ? y1 : startY + i;

            if (!IsValidPlacement(x, y))
                return false;
        }

        for (int i = 0; i < size; i++)
        {
            int x = (x1 == x2) ? x1 : startX + i;
            int y = (y1 == y2) ? y1 : startY + i;
            board[y, x] = 'O';
        }

        return true;
    }

    private static bool IsValidPlacement(int x, int y)
    {
        if (x < 0 || x >= Size || y < 0 || y >= Size)
            return false;

        if (board[y, x] != '~')
            return false;

        for (int i = Math.Max(0, y - 1); i <= Math.Min(Size - 1, y + 1); i++)
        {
            for (int j = Math.Max(0, x - 1); j <= Math.Min(Size - 1, x + 1); j++)
            {
                if (board[i, j] == 'O')
                    return false;
            }
        }

        if (x == 0 || x == Size - 1 || y == 0 || y == Size - 1)
            return false;

        return true;
    }

    private static int ReadCoordinate(string prompt)
    {
        while (true)
        {
            Console.Write($"{prompt} (1-{Size}): ");
            if (int.TryParse(Console.ReadLine(), out int coord) && coord >= 1 && coord <= Size)
                return coord;
            Console.WriteLine($"Ошибка! Введите число от 1 до {Size}.");
        }
    }
}