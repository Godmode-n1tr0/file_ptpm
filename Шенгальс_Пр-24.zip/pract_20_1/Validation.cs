﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace pract_20_1
{
    public static class Validation
    {
        public static string ValidateString(string value, string fieldName)
        {
            for (int i = 0; i < value.Length; i++)
            {
                if (char.IsDigit(value[i]))
                    return $"{fieldName} не может быть числом.\n";

            }
            if (value.Length > 2)
            {
                return $"{fieldName} должно быть не менее 2 символов.\n";
            }
            if (value.Length > 20)
            {
                return $"{fieldName} должно быть не более 20 символов.\n";
            }
            return string.Empty;
        }

        public static string ValidatePositiveNumber(int value, string fieldName)
        {
            if (value <= 0)
            {
                return $"{fieldName} должно быть положительным числом.\n";
            }
                
            return string.Empty;
        }

        public static string ValidateDates(DateTime start, DateTime end, string startFieldName, string endFieldName, bool checkNotPast = false)
        {
            string errors = string.Empty;
            if (start >= end)
                errors += $"{startFieldName} должна быть раньше {endFieldName}.\n";

            if (checkNotPast && start < DateTime.Today)
                errors += $"{startFieldName} не может быть в прошлом.\n";
            return errors;
        }
    }
}
