﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.Button;

namespace pract3_up
{
    public partial class Form1 : Form
    {
        int curr_question = 0;
        string[,] questions = new string[10, 6];
        int correct_answ = 0;
        const char answer = '^';
        public Form1()
        {
            InitializeComponent();
            groupBox2.Visible = false;
            groupBox1.Visible = false;
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton1.Text == questions[curr_question, 4])
                {
                    correct_answ++;
                }
            }
            if (radioButton2.Checked)
            {
                if (radioButton2.Text == questions[curr_question, 4])
                {
                    correct_answ++;
                }
            }
            if (radioButton3.Checked)
            {
                if (radioButton3.Text == questions[curr_question, 4])
                {
                    correct_answ++;
                }
            }
            if (curr_question == 8)
            { 
                button1.Visible = false;
                button2.Visible = true;
            }

            curr_question++;
            this.Text = "Вопрос " + (curr_question + 1);
            label1.Text = questions[curr_question, 0];
            radioButton1.Text = questions[curr_question, 1];
            radioButton2.Text = questions[curr_question, 2];
            radioButton3.Text = questions[curr_question, 3];
            if (File.Exists(questions[curr_question, 5]) && string.IsNullOrEmpty(questions[curr_question, 5]))
            {
                pictureBox1.Image = Image.FromFile(questions[curr_question, 5]);
            }
            else
            {
                pictureBox1 = null;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            button2.Visible = false;
            groupBox2.Visible = false;
            string line;
            using (StreamReader file = new StreamReader("quest.txt"))
            {
                while (!file.EndOfStream && curr_question < questions.GetLength(0))
                {
                    questions[curr_question, 0] = file.ReadLine();
                    for (int i = 1; i <= 3; i++)
                    {
                        questions[curr_question, i] = file.ReadLine();
                    }
                    questions[curr_question, 4] = file.ReadLine();
                    questions[curr_question, 5] = file.ReadLine();
                    curr_question++;
                }
            }//цикл заполнения
            curr_question = 0;
            this.Text = $"Вопрос {curr_question + 1} из {10}";
            label1.Text = questions[0, 0];
            if (questions[curr_question, 4].Contains("^"))
            {
                groupBox1.Visible = Enabled;
                checkBox1.Text = questions[0, 1];
                checkBox2.Text = questions[0, 2];
                checkBox3.Text = questions[0, 3];
            }
            else
            {
                groupBox2.Visible = Enabled;
                radioButton1.Text = questions[0, 1];
                radioButton2.Text = questions[0, 2];
                radioButton3.Text = questions[0, 3];
            }

            if (File.Exists(questions[curr_question, 5]))
            {
                pictureBox1.Image = Image.FromFile(questions[curr_question, 5]);
            }
            else
            {
                pictureBox1 = null;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked)
            {
                if (radioButton1.Text == questions[curr_question, 4])
                {
                    correct_answ++;
                }
            }
            if (radioButton2.Checked)
            {
                if (radioButton2.Text == questions[curr_question, 4])
                {
                    correct_answ++;
                }
            }
            if (radioButton3.Checked)
            {
                if (radioButton3.Text == questions[curr_question, 4])
                {
                    correct_answ++;
                }
            }
            if (curr_question == 9)
            {
                button2.Enabled = false;
            }
            MessageBox.Show($"Верно на все {correct_answ} вопросов");
        }
    }
}
