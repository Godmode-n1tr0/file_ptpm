﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace pract7
{
    public partial class Form2 : Form
    {
        Form1 t1;
        int index = 0;
        public Form2()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            index = 0;
            index += 1;
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                t1 = new Form1(textBox1.Text, index);
                t1.ShowDialog();
            }
            else
            {
                MessageBox.Show($"Строки не могу быть пустыми");
                return;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            index = 0;
            index += 2;
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                t1 = new Form1(textBox1.Text, index);
                t1.ShowDialog();
            }
            else
            {
                MessageBox.Show($"Строки не могу быть пустыми");
                return;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            index = 0;
            index += 3;
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                t1 = new Form1(textBox1.Text, index);
                t1.ShowDialog();
            }
            else
            {
                MessageBox.Show($"Строки не могу быть пустыми");
                return;
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            index = 0;
            index += 4;
            if (!string.IsNullOrEmpty(textBox1.Text))
            {
                t1 = new Form1(textBox1.Text, index);
                t1.ShowDialog();
            }
            else
            {
                MessageBox.Show($"Строки не могу быть пустыми");
                return;
            }
        }
        private void createmas()
        {
            dataGridView1.ColumnCount = 4;
            dataGridView1.Columns[0].HeaderText = "Никнейм";
            dataGridView1.Columns[1].HeaderText = "Время прохождения";
            dataGridView1.Columns[2].HeaderText = "Уровень сложности";
            dataGridView1.Columns[3].HeaderText = "Количество ходов";
            dataGridView1.Rows.Clear();
            using (StreamReader file = new StreamReader("Record.txt"))
            {
                do
                {
                    string[] result = new string[4];
                    for (int j = 0; j < 4; j++)
                    {
                        result[j] = file.ReadLine();
                    }
                    dataGridView1.Rows.Add(result[0], result[1], result[2], result[3]);
                }
                while (!file.EndOfStream);
            }
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            createmas();
        }

        private void tabControl1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (tabControl1.SelectedIndex == 1)
            {
                createmas();
            }
        }
    }
}
