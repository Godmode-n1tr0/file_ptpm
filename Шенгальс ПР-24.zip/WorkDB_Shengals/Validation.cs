﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace WorkDB_Shengals
{
    public class Validation
    {
        public static void UpdateData(DataGridView tabl)
        {
            SqlDataAdapter adptr;
            DataTable table;
            SqlConnection connect = new SqlConnection(@"Data Source=PC325L-03\SQLEXPRESS;Initial Catalog=SecurityDB_Shengals;Integrated Security=True;");
            connect.Open();
            adptr = new SqlDataAdapter("select * from User_tbl", connect);
            table = new DataTable();
            adptr.Fill(table);
            tabl.DataSource = table;
            tabl.DataSource = table;
            connect.Close();
        }
        public static string ValLog1(string log, string pass)
        {
            string a = "0";
            if (String.IsNullOrEmpty(log))
            {
                a = "1";
            }
            else if (String.IsNullOrEmpty(pass))
            {
                a = "2";
            }
            return a;
        }
        public static string ValLog(string log, string pass, string valpass)
        {
            string a = "0";
            if (String.IsNullOrEmpty(log))
            {
                a = "1";
            }
            else if (String.IsNullOrEmpty(pass))
            {
                a = "2";
            }
            else if (pass != valpass)
            {
                a = "3";
            }
            return a;
        }
        public static string ValPass(string pass, string Valpass)
        {
            string a = "0";
            if (String.IsNullOrEmpty(pass))
            {
                a = "1";
            }
            else if (String.IsNullOrEmpty(Valpass))
            {
                a = "2";
            }
            else if (pass != Valpass)
            {
                a = "3";
            }
            return a;
        }
        public static string Valadmin(string log, string pass, string role)
        {
            string a = "0";
            if (String.IsNullOrEmpty(log))
            {
                a = "1";
            }
            else if (String.IsNullOrEmpty(pass))
            {
                a = "2";
            }
            else if (String.IsNullOrEmpty(role))
            {
                a = "3";
            }
            else if (role != "Admin" && role != "User")
            {
                a = "4";
            }
            return a;
        }
    }
}
