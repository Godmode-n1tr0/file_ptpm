﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _15_pract
{
    class SubjectIndex
    {
        private Dictionary<string, List<int>> index;

        public SubjectIndex()
        {
            index = new Dictionary<string, List<int>>();
        }

        public void AddEntry(string word, int pageNumber)
        {
            if (string.IsNullOrWhiteSpace(word))
                throw new ArgumentException("Слово не может быть пустым.");

            if (pageNumber <= 0)
                throw new ArgumentException("Номер страницы должен быть положительным числом.");

            if (!index.ContainsKey(word))
            {
                index[word] = new List<int>();
            }

            if (index[word].Count >= 10)
                throw new InvalidOperationException("Нельзя добавить более 10 номеров страниц для одного слова.");

            index[word].Add(pageNumber);
        }
        public string PrintIndex()
        {
            string result = "";
            foreach (var entry in index)
            {
                result += $"{entry.Key}: {string.Join(", ", entry.Value)}\n";
            }
            return result;
        }

        public string PrintPagesForWord(string word)
        {
            if (index.ContainsKey(word))
            {
                return $"{word}: {string.Join(", ", index[word])}";
            }
            else
            {
                return $"Слово '{word}' не найдено в указателе.";
            }
        }

        public void RemoveEntry(string word)
        {
            if (index.ContainsKey(word))
            {
                index.Remove(word);
            }
            else
            {
                throw new KeyNotFoundException($"Слово '{word}' не найдено в указателе.");
            }
        }
        public void LoadFromFile(string filePath)
        {
            var lines = System.IO.File.ReadAllLines(filePath);
            foreach (var line in lines)
            {
                var parts = line.Split(':');
                if (parts.Length == 2)
                {
                    string word = parts[0].Trim();
                    var pageNumbers = parts[1].Split(',').Select(int.Parse).ToList();
                    foreach (var pageNumber in pageNumbers)
                    {
                        AddEntry(word, pageNumber);
                    }
                }
            }
        }

        public void SaveToFile(string filePath)
        {
            var lines = index.Select(entry => $"{entry.Key}: {string.Join(",", entry.Value)}");
            System.IO.File.WriteAllLines(filePath, lines);
        }
    }
}
