﻿using pract20;

Console.WriteLine("Добро пожаловать в систему учета театральных спектаклей!");

while (true)
{
    Console.WriteLine("\nВыберите действие:");
    Console.WriteLine("1 - Добавить гастрольный спектакль");
    Console.WriteLine("2 - Добавить местный спектакль");
    Console.WriteLine("3 - Показать все спектакли");
    Console.WriteLine("0 - Выход");

    string choice = Convert.ToString(Console.ReadLine());

    switch (choice)
    {
        case "1":
            AddTouringSpectacle();
            break;
        case "2":
            AddLocalSpectacle();
            break;
        case "3":
            Console.Clear();
            ShowAllSpectacles();
            break;
        case "0":
            return;
        default:
            Console.WriteLine("Неверный ввод. Попробуйте снова.");
            break;
    }
}

    static void AddTouringSpectacle()
    {
    try
    {
        Console.Write("Название спектакля: ");
        string title = Convert.ToString(Console.ReadLine());

        Console.Write("Жанр: ");
        string genre = Convert.ToString(Console.ReadLine());

        Console.Write("Автор: ");
        string author = Convert.ToString(Console.ReadLine());

        Console.Write("Режиссер: ");
        string director = Convert.ToString(Console.ReadLine());

        DateTime start, end;
        while (true)
        {
            Console.Write("Начало гастролей (дд.мм.гггг): ");
            if (DateTime.TryParse(Convert.ToString(Console.ReadLine()), out start))
                break;
            Console.WriteLine("Некорректный формат даты. Попробуйте снова.");
        }

        while (true)
        {
            Console.Write("Конец гастролей (дд.мм.гггг): ");
            if (DateTime.TryParse(Convert.ToString(Console.ReadLine()), out end))
                break;
            Console.WriteLine("Некорректный формат даты. Попробуйте снова.");
        }

        Console.Write("Площадка: ");
        string venue = Convert.ToString(Console.ReadLine());

        var spectacle = new GSpectacl(title, genre, author, director, start, end, venue);
        Console.WriteLine("Гастрольный спектакль успешно добавлен!");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Ошибка: {ex.Message}");
    }
}

static void AddLocalSpectacle()
{
    try
    {
        Console.Write("Название спектакля: ");
        string title = Convert.ToString(Console.ReadLine());

        Console.Write("Жанр: ");
        string genre = Convert.ToString(Console.ReadLine());

        Console.Write("Автор: ");
        string author = Convert.ToString(Console.ReadLine());

        Console.Write("Режиссер: ");
        string director = Convert.ToString(Console.ReadLine());

        Console.Write("Название театра: ");
        string theater = Convert.ToString(Console.ReadLine());

        Console.Write("Количество показов в сезоне: ");
        int count = int.Parse(Convert.ToString(Console.ReadLine()));

        var spectacle = new MSpectacl(title, genre, author, director, theater, count);
        Console.WriteLine("Местный спектакль успешно добавлен!");
    }
    catch (Exception ex)
    {
        Console.WriteLine($"Ошибка: {ex.Message}");
    }
}

static void ShowAllSpectacles()
{
    if (Spectacl.AllSpectacles.Count == 0)
    {
        Console.WriteLine("В системе нет спектаклей.");
        return;
    }

    Console.Write("\n=== ВСЕ СПЕКТАКЛИ ===");
    foreach (var spectacle in Spectacl.AllSpectacles)
    {
        Console.WriteLine(spectacle.Info());
        Console.WriteLine("----------------------");
    }
}