﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.ProgressBar;

namespace pract12
{
    public partial class Form1 : Form
    {
        int count = 0;
        int summa = 0;
        int stavka = 0;
        Random random = new Random();
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            summa = Convert.ToInt32(label7.Text);
            if (summa <= 0)
            {
                MessageBox.Show("У вас не осталась денег, Game Over.");
                return;
            }
            stavka = Convert.ToInt32(numericUpDown1.Value);
            label7.Text = Convert.ToString(summa - stavka);
            label6.Text = "";
            pictureBox4.Visible = false;
            button1.Enabled = false;
            button3.Enabled = true;
            timer1.Start();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            int summa = Convert.ToInt32(label7.Text);
            label7.Text = Convert.ToString(1000);
            MessageBox.Show("Вы начали новую игру");
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;
            label1.Text = "0";
            label2.Text = "0";
            label3.Text = "0";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label6.Text = "";
        }

        private void button3_Click(object sender, EventArgs e)
        {
            timer1.Stop();
            if (summa <= 0)
            {
                MessageBox.Show("У вас не осталась денег, Game Over.");
                return;
            }
            if (Convert.ToInt32(label1.Text)==7) {

                count++;
            }
            if (Convert.ToInt32(label2.Text) == 7)
            {

                count++;
            }
            if (Convert.ToInt32(label3.Text) == 7)
            {

                count++;
            }
            if (count == 1)
            {
                label7.Text = Convert.ToString(summa += 7 * stavka / 3);
                pictureBox4.Image = Image.FromFile("money.jpg");
                label6.Text = "Большая семерка 7";
                pictureBox4.Visible = true;
                count = 0;
            }
            if (count == 2)
            {
                label7.Text = Convert.ToString(summa += 7 * stavka / 2);
                pictureBox4.Image = Image.FromFile("money.jpg");
                label6.Text = "Две 7 поздравляем";
                pictureBox4.Visible = true;
                count = 0;
            }
            if (count == 3)
            {
                label7.Text = Convert.ToString(summa * 10);
                pictureBox4.Image = Image.FromFile("money.jpg");
                label6.Text = "3 СЕМЕРГИ ПОЗДРАВЛЯЕМ ВАС";
                pictureBox4.Visible = true;
                count = 0;
            }
            button1.Enabled = true;
            button3.Enabled = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            string a = Convert.ToString(label1.Text = Convert.ToString(random.Next(1, 8)));
            switch (a)
            {
                case "1":
                    {
                        pictureBox1.Image = Image.FromFile("1.jfif");
                        break;
                    }
                case "2":
                    {
                        pictureBox1.Image = Image.FromFile("2.jfif");
                        break;
                    }
                case "3":
                    {
                        pictureBox1.Image = Image.FromFile("3.jpg");
                        break;
                    }
                case "4":
                    {
                        pictureBox1.Image = Image.FromFile("4.jpg");
                        break;
                    }
                case "5":
                    {
                        pictureBox1.Image = Image.FromFile("5.jpg");
                        break;
                    }
                case "6":
                    {
                        pictureBox1.Image = Image.FromFile("6.jpg");
                        break;
                    }
                case "7":
                    {
                        pictureBox1.Image = Image.FromFile("7.jpg");
                        break;
                    }
            }
            string b = Convert.ToString(label2.Text = Convert.ToString(random.Next(1, 8)));
            switch (b)
            {
                case "1":
                    {
                        pictureBox2.Image = Image.FromFile("1.jfif");
                        break;
                    }
                case "2":
                    {
                        pictureBox2.Image = Image.FromFile("2.jfif");
                        break;
                    }
                case "3":
                    {
                        pictureBox2.Image = Image.FromFile("3.jpg");
                        break;
                    }
                case "4":
                    {
                        pictureBox2.Image = Image.FromFile("4.jpg");
                        break;
                    }
                case "5":
                    {
                        pictureBox2.Image = Image.FromFile("5.jpg");
                        break;
                    }
                case "6":
                    {
                        pictureBox2.Image = Image.FromFile("6.jpg");
                        break;
                    }
                case "7":
                    {
                        pictureBox2.Image = Image.FromFile("7.jpg");
                        break;
                    }
            }
            string c = Convert.ToString(label3.Text = Convert.ToString(random.Next(1, 8)));
            switch (c)
            {
                case "1":
                    {
                        pictureBox3.Image = Image.FromFile("1.jfif");
                        break;
                    }
                case "2":
                    {
                        pictureBox3.Image = Image.FromFile("2.jfif");
                        break;
                    }
                case "3":
                    {
                        pictureBox3.Image = Image.FromFile("3.jpg");
                        break;
                    }
                case "4":
                    {
                        pictureBox3.Image = Image.FromFile("4.jpg");
                        break;
                    }
                case "5":
                    {
                        pictureBox3 .Image = Image.FromFile("5.jpg");
                        break;
                    }
                case "6":
                    {
                        pictureBox3.Image = Image.FromFile("6.jpg");
                        break;
                    }
                case "7":
                    {
                        pictureBox3.Image = Image.FromFile("7.jpg");
                        break;
                    }
            }
        }

        private void numericUpDown2_ValueChanged(object sender, EventArgs e)
        {
            timer1.Interval = Convert.ToInt32(numericUpDown2.Value);
        }
    }
}
