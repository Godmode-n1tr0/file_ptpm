﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_2._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Введите имя файла (с путем, если необходимо): ");
            string filePath = Console.ReadLine();

            try
            {
                if (!File.Exists(filePath))
                {
                    Console.WriteLine("Файл не найден. Пожалуйста, проверьте путь и имя файла.");
                    return;
                }

                string content = File.ReadAllText(filePath);
                Console.WriteLine("\nСодержание файла:\n");
                Console.WriteLine(content);

                string modifiedContent = RemoveBrackets(content);
                    
                Console.WriteLine("\nИзмененное содержание файла:\n");
                Console.WriteLine(modifiedContent);

                Console.Write("\nВведите имя нового файла для сохранения: ");
                string newFilePath = Console.ReadLine();

                File.WriteAllText(newFilePath, modifiedContent);
                Console.WriteLine($"Измененное содержание сохранено в файл: {newFilePath}");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Произошла ошибка: {ex.Message}");
            }
        }

        static string RemoveBrackets(string input)
        {
            StringBuilder result = new StringBuilder();
            bool insideBrackets = false;

            foreach (char c in input)
            {
                if (c == '(' || c == '[' || c == '{')
                {
                    insideBrackets = true;
                }
                else if (c == ')' || c == ']' || c == '}')
                {
                    insideBrackets = false;
                    continue;
                }

                if (!insideBrackets)
                {
                    result.Append(c);
                }
            }

            return result.ToString();
        }
    }
}
