﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract19
{
    public partial class Form1 : Form
    {
        int[,] a = new int[4, 4];
        Random rnd = new Random();
        public Form1()
        {
            InitializeComponent();
        }
        private void MaximumNumStol()
        {
            dataGridView1.RowCount = 4;
            dataGridView1.Rows[3].HeaderCell.Value = "Max";
            for (int j = 0; j < 4; j++)
            {
                int max = a[0, j];
                for (int i = 0; i < 3; i++)
                {
                    if (a[i, j] > max)
                    {
                        max = a[i, j];
                    }
                    dataGridView1.Rows[3].Cells[j].Value = max.ToString();
                }
            }
        }
        private void MinimalNumStr()
        {
            dataGridView1.ColumnCount = 5;
            dataGridView1.Columns[4].HeaderText = "Min";
            for (int i = 0; i < 3; i++)
            {
                int min = a[i, 0];
                for (int j = 1; j < 4; j++)
                {
                    if (a[i, j] < min)
                    {
                        min = a[i, j];
                    }
                }
                dataGridView1[4, i].Value = min.ToString();
            }
            dataGridView1.Columns[4].Width = 60;
        }
        private void CreateMas()
        {
            Font f = new Font("arial", 8, FontStyle.Regular);
            dataGridView1.RowCount = 4;
            dataGridView1.ColumnCount = 4;
            for (int i = 0; i < 3; i++)
            {
                dataGridView1.Rows[i].HeaderCell.Value = (i + 1).ToString();
                for (int j = 0; j < 4; j++)
                {
                    dataGridView1.Columns[j].HeaderCell.Value = (j + 1).ToString();
                    a[i, j] = rnd.Next(-10, 10);
                    dataGridView1[j, i].Value = a[i, j].ToString();
                }
            }
            dataGridView1.Rows[0].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Rows[1].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Rows[2].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.Rows[3].HeaderCell.Style.Alignment = DataGridViewContentAlignment.MiddleCenter;
            dataGridView1.RowHeadersDefaultCellStyle.Font = f;
            dataGridView1.ColumnHeadersDefaultCellStyle.Font = f;
            dataGridView1.DefaultCellStyle.ForeColor = Color.Red;
            dataGridView1.Columns[0].Width = 60;
            dataGridView1.Columns[1].Width = 60;
            dataGridView1.Columns[2].Width = 60;
            dataGridView1.Columns[3].Width = 60;

        }
        private void button1_Click(object sender, EventArgs e)
        {
            CreateMas();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MinimalNumStr();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MaximumNumStol();
        }
    }
}
