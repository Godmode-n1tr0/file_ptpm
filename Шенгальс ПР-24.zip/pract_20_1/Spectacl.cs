﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace pract_20_1
{
    public abstract class Spectacl
    {
        protected Spectacl(string title, string genre, string author, string director)
        {
            ValidateFields(title, genre, author, director);
        }

        private void ValidateFields(string title, string genre, string author, string director)
        {
            string errors = Validation.ValidateString(title, "Название") +
                            Validation.ValidateString(genre, "Жанр") +
                            Validation.ValidateString(author, "Автор") +
                            Validation.ValidateString(director, "Режиссер");

            if (!string.IsNullOrEmpty(errors))
            {
                throw new ArgumentException(errors);
            }
        }

        public string Title { get; protected set; }
        public string Genre { get; protected set; }
        public string Author { get; protected set; }
        public string Director { get; protected set; }

    }
}
