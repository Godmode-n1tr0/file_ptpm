﻿using pract13;
Random r = new Random();
bool playAgain = true;
while (playAgain)
{
    Console.Clear();
    Monstr Hero1 = new Monstr();
    Monstr Hero2 = new Monstr();
    while (Hero1.GetHp() > 0 && Hero2.GetHp() > 0)
    {
        Console.WriteLine("Начинается бой между:");
        Hero1.drawmonster();
        Console.WriteLine();
        Hero2.drawmonster();
        Console.WriteLine();
        Console.WriteLine();

        while (Hero1.GetHp() > 0 && Hero2.GetHp() > 0)
        {
            if (r.NextDouble() > 0.25)
            {
                bool isDoubleDamage = r.NextDouble() < 0.25;
                Hero2.TakeDamage(Hero1.Getdamage(), isDoubleDamage);
            }
            else
            {
                Console.WriteLine($"{Hero1.name} промахнулся!");
            }

            if (Hero2.GetHp() <= 0) break;

            if (r.NextDouble() > 0.25)
            {
                bool isDoubleDamage = r.NextDouble() < 0.25;
                Hero1.TakeDamage(Hero2.Getdamage(), isDoubleDamage);
            }
            else
            {
                Console.WriteLine($"{Hero2.name} промахнулся!");
            }
            Hero1.drawmonster();
            Console.WriteLine();
            Hero2.drawmonster();
            Console.ReadLine();
        }
        Console.WriteLine();
        Console.WriteLine("Итоговый результат:");
        Hero1.drawmonster();
        Console.WriteLine();
        Hero2.drawmonster();
        if (Hero1.GetHp() <= 0)
        {
            Console.WriteLine($"{Hero2.name} победил!");
        }
        else
        {
            Console.WriteLine($"{Hero1.name} победил!");
        }

        Console.WriteLine("Хотите сыграть еще раз? (да/нет)");
        string response = Console.ReadLine();
        playAgain = response.ToLower() == "да";
    }
}
