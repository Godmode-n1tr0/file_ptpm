﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Text;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Xml.Linq;
using System.IO;

namespace pract10._2
{
    public partial class Form1 : Form
    {
        private List<Dairy_products> _products = new List<Dairy_products>();
        public Form1()
        {
            InitializeComponent();
        }

        private void UpdateDataGridView()
        {
            dataGridView1.DataSource = null;
            dataGridView1.DataSource = _products;
        }
        public void Info(string fileName)
        {
            using (StreamWriter sw = new StreamWriter(fileName))
            {
                foreach (var product in _products)
                {
                    sw.WriteLine($"Название: {product.GetName()}, Вес: {product.GetWeight()} г, Жирность: {product.GetFatContent()}%, Производитель: {product.Manufacturer}, Цена: {product.Price} руб.");
                }
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var product = new Dairy_products();
            product.SetName("Молоко");
            product.SetWeight(1000);
            product.SetFatContent(2.5);
            product.Manufacturer = "ОАО «Молоко»";
            product.Price = 80.50m;

            _products.Add(product);
            UpdateDataGridView();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var product = new Dairy_products("Сметана", 500, 20);
            product.Manufacturer = "ЗАО «Сметанкин»";
            product.Price = 45.00m;

            _products.Add(product);
            UpdateDataGridView();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            var product = new Dairy_products
            {
                Manufacturer = "Ферма",
                Price = 200
            };
            product.SetName("Сыр");
            product.SetWeight(300);
            product.SetFatContent(15);

            _products.Add(product);
            UpdateDataGridView();
        }

        private void BtnShow_Click(object sender, EventArgs e)
        {
            Info("products.txt");
            MessageBox.Show("Данные сохранены в файл!");
        }
    }
}
