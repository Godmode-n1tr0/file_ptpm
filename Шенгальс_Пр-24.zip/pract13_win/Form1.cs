using pract13;

namespace pract13_win
{
    public partial class Form1 : Form
    {
        Monstr monstr = new Monstr();
        public Form1()
        {
            InitializeComponent();
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            pictureBox1.Enabled = false;
            pictureBox1.Image = Image.FromFile("Gojo.jfif");
        }
    }
}
