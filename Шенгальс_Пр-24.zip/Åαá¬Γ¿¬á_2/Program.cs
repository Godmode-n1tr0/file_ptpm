﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Практика_2
{
    internal class Program
    {
        static string Reverse(string str)
        {
            string text2 = "";
            for (int i = str.Length - 1; i >= 0; i--)
            {
                text2 += str[i];
            }
            return text2;
        }
        static void Main(string[] args)
        {
            Console.Write("Введите номер задания: ");
            int a1 = Convert.ToInt32(Console.ReadLine());
            if (a1 == 1)
            {
                Console.Clear();
                Console.WriteLine("Введите число");
                int givenSum = Convert.ToInt32(Console.ReadLine());
                int count = 0;
                for (int i = 100; i <= 999 && count < 5; i++)
                {
                    int sum = 0;
                    string num = i.ToString();

                    foreach (char digit in num)
                    {
                        sum += digit - '0';
                    }

                    if (sum == givenSum)
                    {
                        Console.WriteLine(i);
                        count++;
                    }
                }
            }
            else if (a1 == 2)
            {
                Console.Clear();
                Console.Write("Введите число: ");
                int num = Convert.ToInt32(Console.ReadLine());
                string numstr = num.ToString();
                string revers = Reverse(numstr);
                bool b = revers.Contains(numstr);
                if (b == true)
                {
                    Console.WriteLine($"число: {revers} палидром");
                }
                else
                {
                    Console.WriteLine($"число: {revers} не палидром");
                }
            }
            else if (a1 == 3)
            {
                Console.Clear();
                Console.Write("Введите номер первой катушки: ");
                int start = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите номер последней катушки: ");
                int end = Convert.ToInt32(Console.ReadLine());

                int count = 0;

                for (int ticket = start; ticket <= end; ticket++)
                {
                    string ticketStr = ticket.ToString("D5");

                    int sumFirstHalf = (ticketStr[0] - '0') + (ticketStr[1] - '0') + (ticketStr[2] - '0');
                    int sumSecondHalf = (ticketStr[3] - '0') + (ticketStr[4] - '0');

                    if (sumFirstHalf == sumSecondHalf)
                    {
                        Console.WriteLine(ticketStr);
                        count++;
                    }
                }

                Console.WriteLine($"Количество счастливых билетов: {count}");
            }
            else if (a1 == 4)
            {
                for (int number = 100; number <= 999; number++)
                {
                    string numStr = number.ToString();
                    if (numStr[0] != numStr[1] && numStr[0] != numStr[2] && numStr[1] != numStr[2])
                    {
                        Console.WriteLine(number);
                    }
                }
            }
            else if (a1 == 5)
            {
                Console.Clear();
                Console.Write("Введите номер первой катушки: ");
                int start = Convert.ToInt32(Console.ReadLine());

                Console.Write("Введите номер последней катушки: ");
                int end = Convert.ToInt32(Console.ReadLine());
                string c = "00";
                int countd = 0;
                if (start > 99999 && end > 99999)
                {
                    int count = 0;

                    for (int ticket = start; ticket <= end; ticket++)
                    {
                        string ticketStr = ticket.ToString("D5");

                        int sumFirstHalf = (ticketStr[0] - '0') + (ticketStr[1] - '0') + (ticketStr[2] - '0');
                        int sumSecondHalf = (ticketStr[3] - '0') + (ticketStr[4] - '0');


                        if (sumFirstHalf == sumSecondHalf)
                        {
                            Console.WriteLine(ticketStr);
                            bool b = ticketStr.Contains(c);
                            if (b == true)
                            {
                                countd++;
                                Console.WriteLine($"числа с нулями: {ticketStr}");
                            }
                            count++;
                        }
                    }
                    Console.WriteLine($"Нули в числах: {countd}");
                    Console.WriteLine($"Количество счастливых билетов: {count}");
                }
                else
                {
                    Console.WriteLine("У вас введенны не 6-ти значные числа");
                }
            }
        }
    }
}
